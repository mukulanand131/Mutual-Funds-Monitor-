import "../../public/Home.css";

import React from "react";

export default function Home() {
  return (
    <div>
      <main>
        <section className="hero">
          <h1>Mutual Funds Monitor</h1>
          <h2>
            Revolutionizing Mutual Fund Investment with Real-Time Monitoring
          </h2>
          <p>
            Track market prices of mutual funds effortlessly with Mutual Funds
            Monitor, <br /> Say goodbye to traditional investment methods and
            embrace the future of portfolio management !
          </p>
          <a href="/login" className="cta-button">
            Get Started
          </a>
        </section>
        <section className="features">
          <h2>It's no where.</h2>
          <div className="Its_nowhere">
            <div className="comp_1"></div>
            <div className="comp_2"></div>
            <div className="comp_3"></div>
            <div className="comp_4"></div>
            <div className="comp_5"></div>
            <div className="comp_6"></div>
          </div>
          <h2>But only here.</h2>
        </section>
        {/* <section className="testimonials">
          <h2>What Our Users Say</h2>
          <div className="testimonial">
            <blockquote>
              <p>
                "Mutual Funds Now has transformed the way I manage my
                investments. The real-time market updates have been invaluable
                in making informed decisions."
              </p>
            </blockquote>
            <cite>- John Doe, Investor</cite>
          </div>
          <div className="testimonial">
            <blockquote>
              <p>
                "I highly recommend Mutual Funds Now to anyone looking to take
                control of their financial future. It's user-friendly and
                incredibly effective."
              </p>
            </blockquote>
            <cite>- Jane Smith, Entrepreneur</cite>
          </div>
        </section> */}
        <section className="cta">
          <h2>Ready to Get Started?</h2>
          <h2>Finance simplified, in your language.</h2>
          <p>
            Sign up now and start monitoring market prices of mutual funds in
            real-time with Mutual Funds Monitor!
          </p>
          <a href="/register" className="cta-button">
            Get Started
          </a>
        </section>
      </main>
      <footer>
        <p>Made with 💓 by Mukul Anand & Akanksha</p>
        <p>&copy; 2024 Mutual Funds Monitor. All rights reserved.</p>
      </footer>
    </div>
  );
}
