import React, { useState, useEffect } from "react";
import axios from "axios";
import { toast } from 'react-hot-toast';


export default function YourFunds() {
  const [userName, setUserName] = useState(null);
  const [userId, setUserId] = useState(null);
  const [userfundData, setUserFundData] = useState(null);


  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const profileResponse = await axios.get("/profile");
        setUserName(profileResponse.data.name);
        setUserId(profileResponse.data.id);

        const fundDataResponse = await axios.get("/fundData");
        const filteredFundData = fundDataResponse.data.filter((user) =>
          user.fundData.some((fund) => fund.userId === profileResponse.data.id)
        );

        // console.log(filteredFundData[0])
        const extractedData = [];

        // Iterate over filteredFundData array
        for (let i = 0; i < filteredFundData.length; i++) {
          const user = filteredFundData[i];
          // console.log(user)

          // Iterate over fundData array of each user
          for (let j = 0; j < user.fundData.length; j++) {
            const fund = user.fundData[j];
            console.log(fund._id)

            // Split the data string by newline character to extract individual details
            const details = fund.data.split("\n");

            // Create an object to store the extracted details
            const extractedDetails = {};
            extractedDetails["_id"] = fund._id

            // Iterate over the details array to extract key-value pairs
            for (let k = 0; k < details.length; k++) {
              const keyValue = details[k].split(": ");
              const key = keyValue[0].trim(); // Trim any leading or trailing spaces
              const value = keyValue[1].trim(); // Trim any leading or trailing spaces
              extractedDetails[key] = value;
            }

            // Add the extracted details object to the extractedData array
            extractedData.push(extractedDetails);
          }
        }

        
        setUserFundData(extractedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);
console.log(userfundData)
  

// To remove Funds from Your Funds.
const handleRemoveFundFromYourFunds = async (fundId) => {
  try {
    console.log(fundId)
    // Send a request to the backend to remove the fund
    await axios.delete(`/removeFund/${userId}/${fundId}`).then(() => {
      // Display toast message on successful removal
      toast.success("Fund removed successfully!");
    }); // Adjust the endpoint as per your backend setup

    // Update the userfundData state to reflect the removal
    const updatedUserFundData = userfundData.filter(
      (fund) => fund._id !== fundId
    );
    setUserFundData(updatedUserFundData);

  } catch (error) {
    console.error("Error removing fund:", error);
    toast.error("Failed to remove fund. Please try again."); // Display toast message on failure
  }
};
  return (
    <div>
      <div className="userNameDiv">
        {userName ? (
          <h2 className="userKaName">
            Hi {userName}!
          </h2>
        ) : (
          <p className="NoActiveUser">No active user!</p>
        )}
      </div>
      <div className="mutualFundyourFunds">
        {userfundData &&
          userfundData.map((fund, index) => (
            <div key={index}>
              <a href={fund.Link} target="_blank">
                <img src={fund.URL} alt="" />
                {fund.Name}
              </a>
              
              <button
                className="removeFundBtn"
                onClick={() => handleRemoveFundFromYourFunds(fund._id)}
              >
                Remove
              </button>
            </div>
          ))}
      </div>
    </div>
  );
}
