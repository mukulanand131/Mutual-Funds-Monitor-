// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// export default function contact() {
//   const [userName, setUserName] = useState(null);
//   const [userId, setUserId] = useState(null);

//   useEffect(() => {
//     const fetchUserData = async () => {
//       try {
//         const response = await axios.get('/profile');
//         setUserName(response.data.name);
//         setUserId(response.data.id);

//         const uId = response.data.id
//         // console.log(response.data.name)
//         // console.log(response.data.id)
//         const user = await User.findOne({ uId });
//         console.log(userId)

//       } catch (error) {
//         console.error('Error fetching user data:', error);
//       }

//     };
//     console.log(userName)
//     console.log(userId)

//     fetchUserData();
//   }, []); // Empty dependency array to run effect only once on mount

//   return (
//     <div>
//       <div className="userNameDiv">{userName ? <h2 className='userKaName'>Hi {userName}!</h2> : <p className="NoActiveUser">No any active user!</p>}</div>
//       <p>Contact</p>
//     </div>
//   )
// }

import "../../public/contact.css";
import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Contact() {
  const [userName, setUserName] = useState(null);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get("/profile");
        setUserName(response.data.name);
        setUserId(response.data.id);

        // Additional logic can be added here
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []); // Empty dependency array to run effect only once on mount

  return (
    <div>
      <div className="userNameDiv">
        {userName ? (
          <h2 className="userKaName">Hi {userName}!</h2>
        ) : (
          <p className="NoActiveUser">No any active user!</p>
        )}
      </div>
      <section className="contact" id="contact">
        <div className="contact-text">
          <h2>
            Contact <span>Us</span>
          </h2>
          <h4>Let's work Together</h4>
          <p>
            Let's work together to bring your ideas to life! We are excited to
            hear from you and explore how we can collaborate to achieve your
            goals. Whether you have a project in mind, a question to ask, or
            just want to connect, feel free to reach out. We are here to listen,
            share ideas, and find the best solutions to meet your needs. You can
            contact us via the provided email address or through the contact
            form below. We look forward to the opportunity to work together and
            make your vision a reality.
          </p>
          <div className="contact-list">
            <ul>
              <li>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAVdJREFUSEvtlt1xwkAMhFe8EZqATkglgUoCleBUEjoJTYAflVmEDp998Q3mHGYS7okxoE+7+vEJHnTkQVw8wb/mfGx1rUso3gEsC2ewh+ADU6k87hVc6xyKr8LAOJxggakc+PAKPuoGclYLKLZFE/C4grWr/hk8k00ReFvQJW4abKorTLB1awYlcdLPqF/oZBZspAMErzfDrV92nSbNgqlWsAoqG7XJKrfJoFI/+5BAFvwiAqvNG4B5aLgJql71R91FCTvopBpi9FpNMI9lT8sMDnAe2ZnnkQinay1LxN9RLXAz2OCsF61zeBw0ZW07uUFgl5Wykd/5jPr8p8bwLjADt+vetNu636xtn7vB6brH1o8GblrPzzNZJ1U2HxZRnKWMZfXfAde6uiyL8V6LyZXZXRRDTO3/j2/E6CJgo0LVvAz4lioF56rlKzbM+fN6W8rabJz/Z/U3pknXH0t44JcAAAAASUVORK5CYII=" />
                mukulanand131@gmail.com
              </li>
              <li>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAcBJREFUSEvlls11wkAMhEfcgCagkkAlgUoClQCVxKkkbgK4oTxZXvbXu+BsHofoaIM/S5qZNeFFRS/iogw+8w4TNJhSU/Ml8+ALfwJYAWjBOGFOu1rwYbCFGlZVeBrsQ1sAi55eDR6Dz3wAYdODGsxojStvwDjUhMfgC7MHNYMO4YQ9pnQcu3MffOUVGCIogLCOlBzCZ7SsBV6A8d2Dt1FH7u4ZR8xpWx/M2Hv2Se1+LLUbaFi2KxWWKbv7Fr8YsXlcStU7ED660HABbpj8CdgXmN3z0PWR4447vrIITDyrUWm6C6+r6iVcRlU6uVzbuLaKvRzDVYRiy2y2D4GtrcJdy2mlGpDyIzSM2gx8+JBwAa5nZeQ3bBy4voCWyfTiwZI/Fl3vhr7WsUvnIawB4VTK9jxYBSURKg+PTya5LyK84a3fa3NPs8LBUv4CUbjGqFTYeU7TsRjFnt2XTBksv/I7150S7g/J+skVnP6nO9EeAxt4SlQ52/gq9yL4cbBpy7eTVa9qoMUEX70eRHgSQlJ+7j/VsTtPa6n3hKrDyUfQ50adWqSvalW4WxkhPj/qvIqNpxel7/C64Ky8/Zv/D/wDUo/6H9V+D9UAAAAASUVORK5CYII=" />
                +91 82718 62583
              </li>
            </ul>

            {/* For Akanksha */}
            <ul>
              <li>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAVdJREFUSEvtlt1xwkAMhFe8EZqATkglgUoCleBUEjoJTYAflVmEDp998Q3mHGYS7okxoE+7+vEJHnTkQVw8wb/mfGx1rUso3gEsC2ewh+ADU6k87hVc6xyKr8LAOJxggakc+PAKPuoGclYLKLZFE/C4grWr/hk8k00ReFvQJW4abKorTLB1awYlcdLPqF/oZBZspAMErzfDrV92nSbNgqlWsAoqG7XJKrfJoFI/+5BAFvwiAqvNG4B5aLgJql71R91FCTvopBpi9FpNMI9lT8sMDnAe2ZnnkQinay1LxN9RLXAz2OCsF61zeBw0ZW07uUFgl5Wykd/5jPr8p8bwLjADt+vetNu636xtn7vB6brH1o8GblrPzzNZJ1U2HxZRnKWMZfXfAde6uiyL8V6LyZXZXRRDTO3/j2/E6CJgo0LVvAz4lioF56rlKzbM+fN6W8rabJz/Z/U3pknXH0t44JcAAAAASUVORK5CYII=" />
                akanksha120302@gmail.com
              </li>
              <li>
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAcBJREFUSEvlls11wkAMhEfcgCagkkAlgUoClQCVxKkkbgK4oTxZXvbXu+BsHofoaIM/S5qZNeFFRS/iogw+8w4TNJhSU/Ml8+ALfwJYAWjBOGFOu1rwYbCFGlZVeBrsQ1sAi55eDR6Dz3wAYdODGsxojStvwDjUhMfgC7MHNYMO4YQ9pnQcu3MffOUVGCIogLCOlBzCZ7SsBV6A8d2Dt1FH7u4ZR8xpWx/M2Hv2Se1+LLUbaFi2KxWWKbv7Fr8YsXlcStU7ED660HABbpj8CdgXmN3z0PWR4447vrIITDyrUWm6C6+r6iVcRlU6uVzbuLaKvRzDVYRiy2y2D4GtrcJdy2mlGpDyIzSM2gx8+JBwAa5nZeQ3bBy4voCWyfTiwZI/Fl3vhr7WsUvnIawB4VTK9jxYBSURKg+PTya5LyK84a3fa3NPs8LBUv4CUbjGqFTYeU7TsRjFnt2XTBksv/I7150S7g/J+skVnP6nO9EeAxt4SlQ52/gq9yL4cbBpy7eTVa9qoMUEX70eRHgSQlJ+7j/VsTtPa6n3hKrDyUfQ50adWqSvalW4WxkhPj/qvIqNpxel7/C64Ky8/Zv/D/wDUo/6H9V+D9UAAAAASUVORK5CYII=" />
                +91 90656 55597
              </li>
            </ul>
          </div>
          <div className="contact-icons">
            <ul>
              <li>
                <a href="https://instagram.com/mukul_anand___?igshid=OGQ5ZDc2ODk2ZA==">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAgJJREFUSEvVVktuwkAMfYYVcAk4CeEgraAXKZyEtBcBuu22+6Z3KGSHW48n33EgIQsEUoVEx/P87Oc3JtzpQ3fCxQMApzwFIH+XPyPaXzsi/7/M+MhrEOYAojaX+TOJ+2a8YULrpjgbOOUIjG2JoV4GZN+X8ignmYCwwIiCOBv4xN8edA/CBi3L57LRlghjSVySSDCmWT3TEPjIWxCW/0F7jGnRocR6NOUn38KPHJwRY0Kr8l0hcMaWMLNKdDERAWW8uzNnrDBEAsbOYm0BswscU1P/pzhj6UTHruc/GCB2Sab87ESlwC8YYgeGtC0od/Vy6Y8etMusKn81WAszVfEvS5sIhC9M6BNFBUVk+ajVgUXNUpoQuAzK2GDgFX7G3GtCBLUJRujEcl/k1d0RuKiEcKlk7gWVJSzjs6pMQS/gjK2hzrzs2TTUWfcE1hFTNrGpbDWdsE29gBuCKwmkvHRzW69KL+C7lboqrrDcRZlD8fVirFaopVQfjjHAwRvFNJ9te5zU92vT0N5AhLU6lmUg9gxLZg0W3ARsviil1yeCGoc43SG3TEvuJzYt2PJq02k6v1LV9lzxajlcWONtz2I5w0xYrZ5FVbCwlge9+yKQLQOdF4EiMAOXX/qsPlXv9hVpXvYKFXdd9jTRm5a9upLarrYS13I/e4CF/qZ5ag66G+M/Yrc+LrQp0n8AAAAASUVORK5CYII=" />
                </a>
              </li>
              <li>
                <a href="https://twitter.com/Mukul_Anand__">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAZNJREFUSEvtVslxwkAQ7OEHBGE5EkMkQCSGSJAjsYjEmwTox+DR6txbssp82A9F7dHHXCI8adGTcPEC/jfn57H6ykcQdgAyAAUIX9XvklSlpOT94D/giPGNv0E4tJdCHpScgXH+fXTjOFaAcakJASt6758ZKtYP/dSs4+BC0g3ax1AgnAAoLKloNkzgfa1A9sUyP3hHMpYX2u6I4g0YoqJbjBMWyC3rdVw/Y6iVUi2gVSt37OS6sVgtSWIucaCxTCEVWIiv6Wg+ZgMPMzQkSCx0ERzeSQKWtOe2LOKPJvhc25yHFZdsxzjl8dAZwtaM79gYT6GgzGx2l5PuMlLLktlzWF1gRVsXY3fL7DqSgE8n4LHZbbVWLUkmNTodVOrXaBr+ltnszGF3QK1f8V9j7anduOL+CSmxO3YgyGhLWd6EGgd85XMyKCPHmg4p7MzpJHM1w71KqrdkQB00GQRWh/KRsIG1rZpAyhqhMm61jqv+qiB81CSEiAwGBYbCApcxCsO9OkXhTGfm+dibQOYFPMG0aVcermyPH809ZCEAAAAASUVORK5CYII=" />
                </a>
              </li>
              <li>
                <a href="https://www.linkedin.com/in/mukul-anand-131-/">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAW1JREFUSEvtljFOw0AQRd+UjkVJQwUtZwCJnAMhElHAEeiS3IIuQUK0nABhQU9LSQ4Rx+XAxkm8u3aQLdsyRSy58Hp2n+fP31kLHV3SEZd/Bk50gHKI8koon22oks94qR/A2RYmXBHIU9NwFxzrLcKDAxG+COS0bfDot+pjD7KgJwftghM9R3n3Mn4mkMt2wWb1WO8Q7oEj4IWAG0QW7YObJuxYr9l9nOgxYO45gcz/ysEFm4nKmzNBeSSU1HCxjhGuPQ/0VzBluobaryOEYdFHFIG/PfCMUIYWeOS9nyC4Y26qhfD64DKeUCZb1dbxTYNNXU2N/SuiJ6YkVkO0n9IaV5PazBf6BBLtLEcac2LXun7GBTKyVGPQC8+EDYNT184cSKxThEHO/RtVVgLUldqWebNWuu1cp3txe3B1V++lznr63lxZd8vtYyNTom7Hsc/W7LzNdr/VFLaDJeKa/REoc1IVnk4VJtYN7SzjH8j+9R9wSfyqAAAAAElFTkSuQmCC" />
                </a>
              </li>
            </ul>

            {/* For Akanksha */}
            <ul>
              <li>
                <a href="https://instagram.com/mukul_anand___?igshid=OGQ5ZDc2ODk2ZA==">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAgJJREFUSEvVVktuwkAMfYYVcAk4CeEgraAXKZyEtBcBuu22+6Z3KGSHW48n33EgIQsEUoVEx/P87Oc3JtzpQ3fCxQMApzwFIH+XPyPaXzsi/7/M+MhrEOYAojaX+TOJ+2a8YULrpjgbOOUIjG2JoV4GZN+X8ignmYCwwIiCOBv4xN8edA/CBi3L57LRlghjSVySSDCmWT3TEPjIWxCW/0F7jGnRocR6NOUn38KPHJwRY0Kr8l0hcMaWMLNKdDERAWW8uzNnrDBEAsbOYm0BswscU1P/pzhj6UTHruc/GCB2Sab87ESlwC8YYgeGtC0od/Vy6Y8etMusKn81WAszVfEvS5sIhC9M6BNFBUVk+ajVgUXNUpoQuAzK2GDgFX7G3GtCBLUJRujEcl/k1d0RuKiEcKlk7gWVJSzjs6pMQS/gjK2hzrzs2TTUWfcE1hFTNrGpbDWdsE29gBuCKwmkvHRzW69KL+C7lboqrrDcRZlD8fVirFaopVQfjjHAwRvFNJ9te5zU92vT0N5AhLU6lmUg9gxLZg0W3ARsviil1yeCGoc43SG3TEvuJzYt2PJq02k6v1LV9lzxajlcWONtz2I5w0xYrZ5FVbCwlge9+yKQLQOdF4EiMAOXX/qsPlXv9hVpXvYKFXdd9jTRm5a9upLarrYS13I/e4CF/qZ5ag66G+M/Yrc+LrQp0n8AAAAASUVORK5CYII=" />
                </a>
              </li>
              <li>
                <a href="https://twitter.com/Mukul_Anand__">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAZNJREFUSEvtVslxwkAQ7OEHBGE5EkMkQCSGSJAjsYjEmwTox+DR6txbssp82A9F7dHHXCI8adGTcPEC/jfn57H6ykcQdgAyAAUIX9XvklSlpOT94D/giPGNv0E4tJdCHpScgXH+fXTjOFaAcakJASt6758ZKtYP/dSs4+BC0g3ax1AgnAAoLKloNkzgfa1A9sUyP3hHMpYX2u6I4g0YoqJbjBMWyC3rdVw/Y6iVUi2gVSt37OS6sVgtSWIucaCxTCEVWIiv6Wg+ZgMPMzQkSCx0ERzeSQKWtOe2LOKPJvhc25yHFZdsxzjl8dAZwtaM79gYT6GgzGx2l5PuMlLLktlzWF1gRVsXY3fL7DqSgE8n4LHZbbVWLUkmNTodVOrXaBr+ltnszGF3QK1f8V9j7anduOL+CSmxO3YgyGhLWd6EGgd85XMyKCPHmg4p7MzpJHM1w71KqrdkQB00GQRWh/KRsIG1rZpAyhqhMm61jqv+qiB81CSEiAwGBYbCApcxCsO9OkXhTGfm+dibQOYFPMG0aVcermyPH809ZCEAAAAASUVORK5CYII=" />
                </a>
              </li>
              <li>
                <a href="https://www.linkedin.com/in/mukul-anand-131-/">
                  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAAXNSR0IArs4c6QAAAW1JREFUSEvtljFOw0AQRd+UjkVJQwUtZwCJnAMhElHAEeiS3IIuQUK0nABhQU9LSQ4Rx+XAxkm8u3aQLdsyRSy58Hp2n+fP31kLHV3SEZd/Bk50gHKI8koon22oks94qR/A2RYmXBHIU9NwFxzrLcKDAxG+COS0bfDot+pjD7KgJwftghM9R3n3Mn4mkMt2wWb1WO8Q7oEj4IWAG0QW7YObJuxYr9l9nOgxYO45gcz/ysEFm4nKmzNBeSSU1HCxjhGuPQ/0VzBluobaryOEYdFHFIG/PfCMUIYWeOS9nyC4Y26qhfD64DKeUCZb1dbxTYNNXU2N/SuiJ6YkVkO0n9IaV5PazBf6BBLtLEcac2LXun7GBTKyVGPQC8+EDYNT184cSKxThEHO/RtVVgLUldqWebNWuu1cp3txe3B1V++lznr63lxZd8vtYyNTom7Hsc/W7LzNdr/VFLaDJeKa/REoc1IVnk4VJtYN7SzjH8j+9R9wSfyqAAAAAElFTkSuQmCC" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="contact-form">
          <form action="">
            <input type="text" placeholder="Enter Your Subject" required />
            <textarea
              name=""
              id=""
              cols="40"
              rows="10"
              placeholder="Enter Your Message"
              required
            ></textarea>
            <input type="submit" value="Submit" className="send" />
          </form>
        </div>
      </section>
    </div>
  );
}
