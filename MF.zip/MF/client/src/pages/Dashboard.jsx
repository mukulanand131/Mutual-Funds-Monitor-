import "../../public/Dashboard.css";
import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Dashboard() {
  const [userName, setUserName] = useState(null);
  const [pythonData, setPythonData] = useState("");
  const [userFundData, setUserFundData] = useState([]);
  const [selectedFund, setSelectedFund] = useState("");
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get("/profile");
        setUserName(response.data.name);
        setUserId(response.data.id);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();

    const fetchUserFundData = async () => {
      try {
        const response = await axios.get("/fundData");
        const filteredFundData = response.data.filter((user) =>
          user.fundData.some((fund) => fund.userId === userId)
        );

        const extractedData = [];
        for (let i = 0; i < filteredFundData.length; i++) {
          const user = filteredFundData[i];
          for (let j = 0; j < user.fundData.length; j++) {
            const fund = user.fundData[j];
            const details = fund.data.split("\n");
            const extractedDetails = { _id: fund._id };
            for (let k = 0; k < details.length; k++) {
              const keyValue = details[k].split(": ");
              const key = keyValue[0].trim();
              const value = keyValue[1].trim();
              extractedDetails[key] = value;
            }
            extractedData.push(extractedDetails);
          }
        }
        setUserFundData(extractedData);
      } catch (error) {
        console.error("Error fetching user fund data:", error);
      }
    };

    if (userId) {
      fetchUserFundData();
    }
  }, [userId]);

  const handleSelectFund = async (event) => {
    const selectedId = event.target.value;
    setSelectedFund(selectedId);

    // Find the selected fund URL
    const selectedFundData = userFundData.find(
      (fund) => fund._id === selectedId
    );
    const fundURL = selectedFundData ? selectedFundData.Link : "";

    // Define the fetchData function here
    const fetchData = async (fundURL) => {
      try {
        const response = await axios.post("/pythonData", { fundURL });
        console.log(response.data);
        setPythonData(response.data);
      } catch (error) {
        console.error("Error fetching Python data:", error);
      }
    };

    // Fetch data only for the selected fund
    if (fundURL) {
      try {
        await fetchData(fundURL);
      } catch (error) {
        console.error("Error fetching Python data:", error);
      }
    }
  };

  return (
    <div>
      <div className="userNameDiv">
        {userName ? (
          <h2 className="userKaName">Hi {userName}!</h2>
        ) : (
          <p className="NoActiveUser">No any active user!</p>
        )}
      </div>

      {/* <h1>Dashboard</h1> */}
      {/* Display loading message while fetching user data */}
      {/* Once user data is fetched, display the user's name */}

      <div className="mutualFundDashboard">
        <div>
          <h2>Select your fund:</h2>
          <select onChange={handleSelectFund} value={selectedFund}>
            <option value="">Select Fund</option>
            {userFundData.map((fund) => (
              <option key={fund._id} value={fund._id}>
                {fund.Name}
              </option>
            ))}
          </select>
        </div>

        {/* Display selected fund details */}
        {selectedFund && (
          <div className="mutualFundDashboardSelectedFund">
            {/* <h2>Selected Fund: </h2> */}
            {userFundData.map((fund) => {
              if (fund._id === selectedFund) {
                return (
                  <div key={fund._id}>
                    <a href={fund.Link} target="_blank">
                      <img src={fund.URL} alt="" />
                      {fund.Name}
                    </a>
                  </div>
                );
              }
              return null;
            })}
          </div>
        )}
      </div>
      <p>Python Script Output: {pythonData.data1}</p>
      <p>Python Script Output: {pythonData.data2}</p>
      <p>Python Script Output: {pythonData.data3}</p>
    </div>
  );
}
