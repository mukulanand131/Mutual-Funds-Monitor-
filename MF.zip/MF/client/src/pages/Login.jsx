import "../../public/Register_Login.css";
import React, { useState, useContext } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../../context/userContext';

export default function Login() {
  const navigate = useNavigate();
  const { loginUser } = useContext(UserContext);
  const [data, setData] = useState({
    email: '',
    password: '',
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    const { email, password } = data;
    try {
      const response = await axios.post('/login', {
        email,
        password,
      });
      const userData = response.data;
      if (userData.error) {
        toast.error(userData.error);
      } else {
        loginUser(userData); // Update user context with user data
        setData({ email: '', password: '' }); // Clear form fields
        toast.success('Login Successful. Welcome!');
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label htmlFor="email">Email:</label>
        <input
          className="input-field"
          type="email"
          placeholder="Email"
          value={data.email}
          onChange={(e) => setData({ ...data, email: e.target.value })}
        />

        <label htmlFor="password">Password:</label>
        <input
          className="input-field"
          type="password"
          placeholder="********"
          value={data.password}
          onChange={(e) => setData({ ...data, password: e.target.value })}
        />

        <button type="submit" className="submit-button">
          Login
        </button>
      </form>
    </div>
  );
}

