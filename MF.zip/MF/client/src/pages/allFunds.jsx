import React, { useState, useEffect } from "react";
import axios from "axios";
import "../../public/allFunds.css";
import { toast } from 'react-hot-toast';
// import 'react-toastify/dist/ReactToastify.css';


export default function AllFunds() {
  const [userName, setUserName] = useState(null);
  const [userId, setUserId] = useState(null); // New state to store user ID
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredFunds, setFilteredFunds] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(60); // Number of items to display per page
  const [pageNumberLimit] = useState(5);
  const [maxPageNumberLimit, setMaxPageNumberLimit] = useState(5);
  const [minPageNumberLimit, setMinPageNumberLimit] = useState(0);


  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get("/profile");
        setUserName(response.data.name);
        setUserId(response.data.id); // Assuming response.data.id contains the user's ID
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  // Function to handle search input change
  const handleSearchInputChange = (event) => {
    setSearchQuery(event.target.value);
    setCurrentPage(1); // Reset current page when search query changes
  };

  // Filter mutual funds based on search query
  useEffect(() => {
    const filtered = mutualFunds.filter((fund) =>
      fund.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredFunds(filtered);
  }, [searchQuery]);

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredFunds.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Calculate total number of pages
  const totalPages = Math.ceil(filteredFunds.length / itemsPerPage);

  // Define your mutual funds array here
  const mutualFunds = [
    {
      name: "Aditya Birla Sun Life PSU Equity Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-psu-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant Small Cap Fund",
      link: "https://groww.in/mutual-funds/quant-small-cap-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Parag Parikh Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-long-term-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "Nippon India Small Cap Fund",
      link: "https://groww.in/mutual-funds/nippon-india-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Nippon India Multi Cap Fund",
      link: "https://groww.in/mutual-funds/nippon-india-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Quant Mid Cap Fund",
      link: "https://groww.in/mutual-funds/quant-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Quant Infrastructure Fund",
      link: "https://groww.in/mutual-funds/quant-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Nippon India Large Cap Fund",
      link: "https://groww.in/mutual-funds/nippon-india-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "SBI PSU Fund",
      link: "https://groww.in/mutual-funds/sbi-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Small Cap Fund",
      link: "https://groww.in/mutual-funds/tata-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Groww Nifty Total Market Index Fund",
      link: "https://groww.in/mutual-funds/groww-nifty-total-market-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Axis Small Cap Fund",
      link: "https://groww.in/mutual-funds/axis-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Motilal Oswal Midcap Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-focused-midcap-30-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/hdfc-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Quant ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/quant-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "ICICI Prudential BHARAT 22 FOF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-bharat-22-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Bluechip Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-focused-bluechip-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "SBI Small Cap Fund",
      link: "https://groww.in/mutual-funds/sbi-small-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Digital India Fund",
      link: "https://groww.in/mutual-funds/tata-digital-india-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "HDFC Mid-Cap Opportunities Fund",
      link: "https://groww.in/mutual-funds/hdfc-mid-cap-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "SBI Long Term Equity Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-tax-gain-scheme-93-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Equity & Debt Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-balanced-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Groww Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/groww-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Tata Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/tata-index-fund-nifty-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "ICICI Prudential Technology Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-technology-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Infrastructure Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "SBI Gold Fund",
      link: "https://groww.in/mutual-funds/sbi-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "SBI Magnum Mid Cap Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "JM Flexicap Fund",
      link: "https://groww.in/mutual-funds/jm-multi-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Nippon India Power & Infra Fund",
      link: "https://groww.in/mutual-funds/nippon-india-power-infra-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "UTI Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "SBI Bluechip Fund",
      link: "https://groww.in/mutual-funds/sbi-bluechip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "HDFC Small Cap Fund",
      link: "https://groww.in/mutual-funds/hdfc-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Canara Robeco Small Cap Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "SBI Contra Fund",
      link: "https://groww.in/mutual-funds/sbi-contra-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Commodities Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-commodities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Nippon India Growth Fund",
      link: "https://groww.in/mutual-funds/nippon-india-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Smallcap Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-indo-asia-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Quant Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/quant-large-and-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Navi Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "HDFC Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/hdfc-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "SBI Nifty Index Fund",
      link: "https://groww.in/mutual-funds/sbi-nifty-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "SBI Energy Opportunities Fund",
      link: "https://groww.in/mutual-funds/sbi-energy-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Invesco India PSU Equity Fund",
      link: "https://groww.in/mutual-funds/invesco-india-psu-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Tata Gold ETF FoF Fund",
      link: "https://groww.in/mutual-funds/tata-gold-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Kotak Small Cap Fund",
      link: "https://groww.in/mutual-funds/kotak-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HDFC Multi Cap Fund",
      link: "https://groww.in/mutual-funds/hdfc-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Parag Parikh ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "HDFC Defence Fund",
      link: "https://groww.in/mutual-funds/hdfc-defence-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Mirae Asset ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "HDFC Index S&P BSE Sensex Fund",
      link: "https://groww.in/mutual-funds/hdfc-index-fund-sensex-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Mahindra Manulife Small Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Quant Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/quant-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Canara Robeco Bluechip Equity Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Mirae Asset Large & Midcap Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-large-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "DSP Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Bandhan Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-nifty-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Quant Multi Asset Fund",
      link: "https://groww.in/mutual-funds/quant-multi-asset-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Kotak Emerging Equity Fund",
      link: "https://groww.in/mutual-funds/kotak-emerging-equity-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Tata Nifty Midcap 150 Momentum 50 Index Fund",
      link: "https://groww.in/mutual-funds/tata-nifty-midcap-150-momentum-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Axis Midcap Fund",
      link: "https://groww.in/mutual-funds/axis-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/hdfc-taxsaver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Axis Bluechip Fund",
      link: "https://groww.in/mutual-funds/axis-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Motilal Oswal Nifty Microcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-microcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Digital India Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-new-millennium-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant ESG Equity Fund",
      link: "https://groww.in/mutual-funds/quant-esg-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Quant Active Fund",
      link: "https://groww.in/mutual-funds/quant-active-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Nippon India Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "PGIM India Midcap Opportunities Fund",
      link: "https://groww.in/mutual-funds/pgim-india-midcap-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Quant PSU Fund",
      link: "https://groww.in/mutual-funds/quant-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "UTI Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Sundaram Nifty 100 Equal Weight Fund",
      link: "https://groww.in/mutual-funds/sundaram-nifty-100-equal-weight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "HDFC Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/hdfc-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Tata ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/tata-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "UTI Nifty200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Kotak Equity Opportunities Fund",
      link: "https://groww.in/mutual-funds/kotak-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Bandhan ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/bandhan-elss-tax-saver-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Motilal Oswal Nifty Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC Gold Fund",
      link: "https://groww.in/mutual-funds/hdfc-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Motilal Oswal Large and Midcap Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-large-and-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "SBI Large & Midcap Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-multiplier-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bank of India Small Cap Fund",
      link: "https://groww.in/mutual-funds/boi-axa-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "SBI Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/sbi-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Kotak ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/kotak-taxsaver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Motilal Oswal Small Cap Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Groww Value Fund",
      link: "https://groww.in/mutual-funds/groww-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "SBI Technology Opportunities Fund",
      link: "https://groww.in/mutual-funds/sbi-it-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Kotak Infrastructure and Economic Reform Fund",
      link: "https://groww.in/mutual-funds/kotak-infrastructure-economic-reform-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Canara Robeco ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Axis Growth Opportunities Fund",
      link: "https://groww.in/mutual-funds/axis-growth-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Quant Momentum Fund",
      link: "https://groww.in/mutual-funds/quant-momentum-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "HDFC Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/hdfc-retirement-savings-fund-equity-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Tata Infrastructure Fund",
      link: "https://groww.in/mutual-funds/tata-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Zerodha Nifty Large Midcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/zerodha-nifty-large-midcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/zerodha_groww.png",
    },
    {
      name: "Axis ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/axis-elss-tax-saver-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Liquid Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-cash-plus-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bajaj Finserv Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "Quant Absolute Fund",
      link: "https://groww.in/mutual-funds/quant-absolute-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "LIC MF S&P BSE Sensex Fund",
      link: "https://groww.in/mutual-funds/lic-mf-index-fund-sensex-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "ICICI Prudential NASDAQ 100 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nasdaq-100-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Bandhan Small Cap Fund",
      link: "https://groww.in/mutual-funds/bandhan-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Groww Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/groww-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "HDFC Infrastructure Fund",
      link: "https://groww.in/mutual-funds/hdfc-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential PSU Equity Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-psu-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "DSP ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/dsp-elss-tax-saver-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "ICICI Prudential Multi Asset Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-dynamic-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-index-fund-nifty-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "SBI Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Value Discovery Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-value-discovery-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "SBI Infrastructure Fund",
      link: "https://groww.in/mutual-funds/sbi-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Axis Gold Fund",
      link: "https://groww.in/mutual-funds/axis-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Bank of India Mid & Small Cap Equity & Debt Fund",
      link: "https://groww.in/mutual-funds/boi-axa-mid-cap-equity-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "SBI Nifty50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/sbi-nifty50-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Mirae Asset Global X Artificial Intelligence & Technology ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-global-x-artificial-intelligence-technology-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "ICICI Prudential Nifty LargeMidcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-largemidcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HSBC Small Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "SBI Multicap Fund",
      link: "https://groww.in/mutual-funds/sbi-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Value Discovery Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-value-discovery-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Motilal Oswal Nifty 500 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-500-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Tata Nifty India Digital ETF FoF Fund",
      link: "https://groww.in/mutual-funds/tata-nifty-india-digital-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "SBI Healthcare Opportunities Fund",
      link: "https://groww.in/mutual-funds/sbi-pharma-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Midcap Growth Fund",
      link: "https://groww.in/mutual-funds/tata-mid-cap-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Nippon India Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/nippon-india-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Franklin India Smaller Companies Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-india-smaller-companies-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "SBI Flexicap Fund",
      link: "https://groww.in/mutual-funds/sbi-flexicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "HDFC NIFTY200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Nippon India Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-index-fund-nifty-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Motilal Oswal S&P BSE Enhanced Value Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-s-p-bse-enhanced-value-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "ICICI Prudential Nifty50 Value 20 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty50-value-20-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Axis India Manufacturing Fund",
      link: "https://groww.in/mutual-funds/axis-india-manufacturing-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC NIFTY Realty Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-realty-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Tata Ethical Fund",
      link: "https://groww.in/mutual-funds/tata-ethical-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Quant Focused Fund",
      link: "https://groww.in/mutual-funds/quant-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Quant Large Cap Fund",
      link: "https://groww.in/mutual-funds/quant-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Mirae Asset Midcap Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "ICICI Prudential S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-sensex-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Retirement Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-retirement-fund-pure-equity-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Quant Manufacturing Fund",
      link: "https://groww.in/mutual-funds/quant-manufacturing-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Tata Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/tata-equity-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Motilal Oswal Nasdaq 100 FOF Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nasdaq-100-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC NIFTY Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Invesco India Infrastructure Fund",
      link: "https://groww.in/mutual-funds/invesco-india-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "ICICI Prudential Flexicap Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-flexicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Financial Planning FoF Aggressive Plan Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-financial-planning-fof-aggressive-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "DSP Small Cap Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-micro-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Nippon India Pharma Fund",
      link: "https://groww.in/mutual-funds/nippon-india-pharma-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Kotak Multicap Fund",
      link: "https://groww.in/mutual-funds/kotak-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HDFC Pharma And Healthcare Fund",
      link: "https://groww.in/mutual-funds/hdfc-pharma-and-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Tata Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/tata-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Tata Resources & Energy Fund",
      link: "https://groww.in/mutual-funds/tata-resources-energy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "SBI Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/sbi-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-top-100-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "DSP Nifty 50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-equal-nifty-50-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Mid Cap Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-mid-cap-fund-plan-a-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Navi US Total Stock Market FoF Fund",
      link: "https://groww.in/mutual-funds/navi-us-total-stock-market-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Bajaj Finserv Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "SBI Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/sbi-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Motilal Oswal Large Cap Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Kotak Debt Hybrid Fund",
      link: "https://groww.in/mutual-funds/kotak-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Axis Nifty Smallcap 50 Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-smallcap-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Edelweiss Small Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Nippon India Nifty Bank Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-bank-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "HDFC NIFTY Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HDFC Top 100 Fund",
      link: "https://groww.in/mutual-funds/hdfc-top-200-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Mirae Asset NYSE FANG+ ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nyse-fang-plus-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "ICICI Prudential Regular Gold Savings (FOF) Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-regular-gold-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "SBI Focused Equity Fund",
      link: "https://groww.in/mutual-funds/sbi-emerg-buss-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Multicap Fund",
      link: "https://groww.in/mutual-funds/tata-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Navi NASDAQ 100 FoF Fund",
      link: "https://groww.in/mutual-funds/navi-nasdaq-100-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "ICICI Prudential India Opportunities Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-india-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "LIC MF Small Cap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Quantum Small Cap Fund",
      link: "https://groww.in/mutual-funds/quantum-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Bank of India Short Term Income Fund",
      link: "https://groww.in/mutual-funds/boi-axa-short-term-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Medium Term Plan Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-medium-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant Commodities Fund",
      link: "https://groww.in/mutual-funds/quant-commodities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "SBI Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/sbi-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Motilal Oswal ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-focused-long-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC NIFTY Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Kotak Flexicap Fund",
      link: "https://groww.in/mutual-funds/kotak-select-focus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Axis Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/axis-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Zerodha ELSS Tax Saver Nifty Large Midcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/zerodha-elss-tax-saver-nifty-large-midcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/zerodha_groww.png",
    },
    {
      name: "Mirae Asset Global Electric & Autonomous Vehicles ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-global-electric-autonomous-vehicles-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Nippon India Nifty IT Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-it-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Tata India Pharma & Healthcare Fund",
      link: "https://groww.in/mutual-funds/tata-india-pharma-and-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Mirae Asset Large Cap Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-india-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Franklin India NSE Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/franklin-india-index-fund-nse-nifty-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Quant Value Fund",
      link: "https://groww.in/mutual-funds/quant-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Kotak Bluechip Fund",
      link: "https://groww.in/mutual-funds/kotak-50-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "360 ONE Focused Equity Fund",
      link: "https://groww.in/mutual-funds/iifl-focused-equity-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Canara Robeco Emerging Equities Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-emerging-equities-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Bank of India Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/boi-axa-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Nippon India Gold Savings Fund",
      link: "https://groww.in/mutual-funds/nippon-india-gold-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "UTI Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/uti-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "PGIM India Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/pgim-india-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Motilal Oswal Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC Short Term Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-short-term-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Bajaj Finserv Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-large-and-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "Tata Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/tata-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Transportation and Logistics Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-transportation-and-logistics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Nippon India Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-index-fund-sensex-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "DSP Multicap Fund",
      link: "https://groww.in/mutual-funds/dsp-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "DSP Natural Resources and New Energy Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-natural-resources-new-energy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "SBI Banking and PSU Fund",
      link: "https://groww.in/mutual-funds/sbi-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Mahindra Manulife Asia Pacific REITs FoF Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-asia-pacific-reits-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Edelweiss Recently Listed IPO Fund",
      link: "https://groww.in/mutual-funds/edelweiss-maiden-opportunities-fund-series-1-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/sbi-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "LIC MF Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/lic-mf-index-fund-nifty-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "ICICI Prudential Pharma Healthcare and Diagnostics (P.H.D) Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-pharma-healthcare-and-diagnostics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Nippon India Innovation Fund",
      link: "https://groww.in/mutual-funds/nippon-india-innovation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "HDFC Technology Fund",
      link: "https://groww.in/mutual-funds/hdfc-technology-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Quant Liquid Direct Fund",
      link: "https://groww.in/mutual-funds/quant-liquid-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "HDFC Transportation and Logistics Fund",
      link: "https://groww.in/mutual-funds/hdfc-transportation-and-logistics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "SBI Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-monthly-i-come-plan-floater-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty Smallcap 50 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-smallcap-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HDFC Focused 30 Fund",
      link: "https://groww.in/mutual-funds/hdfc-core-satellite-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "SBI Nifty Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/sbi-nifty-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Groww Large Cap Fund",
      link: "https://groww.in/mutual-funds/groww-large-cap-fund-direct-fund-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Motilal Oswal Gold and Silver ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-gold-and-silver-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Motilal Oswal Nifty 200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC Hybrid Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-monthly-i-come-plan-long-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Innovation Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-innovation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/hdfc-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Nippon India Nifty Next 50 Junior BeES FoF Fund",
      link: "https://groww.in/mutual-funds/nippon-india-junior-bees-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Franklin India Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/franklin-india-prima-plus-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Sundaram Financial Services Opportunities Fund",
      link: "https://groww.in/mutual-funds/sundaram-financial-services-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "SBI Magnum Income Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Franklin Build India Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-build-india-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Parag Parikh Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-conservative-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "Edelweiss Mid Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-mid-and-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "UTI Nifty 500 Value 50 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-500-value-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Canara Robeco Multi Cap Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Bank of India ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/bank-of-india-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Groww Overnight Fund",
      link: "https://groww.in/mutual-funds/groww-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Nippon India Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/nippon-india-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Mirae Asset Nifty Smallcap 250 Momentum Quality 100 ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nifty-smallcap-250-momentum-quality-100-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Parag Parikh Liquid Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "Kotak Gold Fund",
      link: "https://groww.in/mutual-funds/kotak-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential US Bluechip Equity Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-us-bluechip-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Kotak Technology Fund",
      link: "https://groww.in/mutual-funds/kotak-technology-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential Manufacturing Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-manufacture-in-india-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Medium Term Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-medium-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HSBC Infrastructure Fund",
      link: "https://groww.in/mutual-funds/hsbc-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "SBI Magnum Children's Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-children’s-benefit-fund-investment-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Edelweiss Nifty Midcap150 Momentum 50 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-midcap150-momentum-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "DSP Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "DSP World Gold FoF Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-world-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "UTI Transportation and Logistics Fund",
      link: "https://groww.in/mutual-funds/uti-transportation-and-logistics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Invesco India Arbitrage Fund",
      link: "https://groww.in/mutual-funds/invesco-india-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Small Cap Fund",
      link: "https://groww.in/mutual-funds/uti-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Mahindra Manulife Multi Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-badhat-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Kotak International REIT FOF Fund",
      link: "https://groww.in/mutual-funds/kotak-international-reit-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential Multicap Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Dividend Yield Equity Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-dividend-yield-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Kotak Nifty AAA Bond Jun 2025 HTM Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-aaa-bond-jun-2025-htm-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "DSP Nifty Smallcap250 Quality 50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-smallcap250-quality-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Parag Parikh Dynamic Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-dynamic-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "Aditya Birla Sun Life ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Groww ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/groww-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Nippon India Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/nippon-india-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Mahindra Manulife Mid Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-unnati-emerging-business-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Bandhan Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/bandhan-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "DSP The Infrastructure Growth and Economic Reforms Regular Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-india-tiger-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "SBI Consumption Opportunities Fund",
      link: "https://groww.in/mutual-funds/sbi-fmcg-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-smallcap-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Navi Nifty IT Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-it-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Canara Robeco Infrastructure Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Quant Consumption Fund",
      link: "https://groww.in/mutual-funds/quant-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "SBI Magnum Gilt Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-gilt-long-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Navi Nifty Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Axis Multicap Fund",
      link: "https://groww.in/mutual-funds/axis-multicap-fund-direct-growth-c",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Auto Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-auto-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Navi Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Franklin India Taxshield Fund",
      link: "https://groww.in/mutual-funds/franklin-india-taxshield-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Baroda BNP Paribas Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/baroda-large-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Canara Robeco Mid Cap Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "SBI Short Term Debt Fund",
      link: "https://groww.in/mutual-funds/sbi-short-term-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "LIC MF Liquid Fund",
      link: "https://groww.in/mutual-funds/lic-mf-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Baroda BNP Paribas Focused Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Tata Arbitrage Fund",
      link: "https://groww.in/mutual-funds/tata-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "HSBC Arbitrage Fund",
      link: "https://groww.in/mutual-funds/hsbc-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Mahindra Manulife Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-top-250-nivesh-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Tata Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/tata-retirement-savings-fund-progressive-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Quant Quantamental Fund",
      link: "https://groww.in/mutual-funds/quant-quantamental-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Axis Nifty 100 Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-100-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Tata Multi Asset Opportunities Fund",
      link: "https://groww.in/mutual-funds/tata-multi-asset-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Groww Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/groww-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Bandhan Sterling Value Fund",
      link: "https://groww.in/mutual-funds/idfc-sterling-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Invesco India Smallcap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-smallcap-fund-direct-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "SBI Retirement Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-retirement-benefit-fund-aggressive-hybrid-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "PGIM India Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/pgim-india-large-and-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Kotak Nasdaq 100 FOF Fund",
      link: "https://groww.in/mutual-funds/kotak-nasdaq-100-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HDFC Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/hdfc-premier-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Baroda BNP Paribas Multi Cap Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Mahindra Manulife Liquid Fund",
      link: "https://groww.in/mutual-funds/mahindra-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Transportation and Logistics Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-transportation-and-logistics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Liquid Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-liquid-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Tata S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/tata-index-fund-sensex-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Taurus Ethical Fund",
      link: "https://groww.in/mutual-funds/taurus-ethical-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant Healthcare Fund",
      link: "https://groww.in/mutual-funds/quant-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "ICICI Prudential Nifty 200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Invesco India Focused Fund",
      link: "https://groww.in/mutual-funds/invesco-india-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Motilal Oswal S&P 500 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-s-p-500-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Kotak Nifty 200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HDFC Long Duration Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-long-duration-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Edelweiss Multi Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Canara Robeco Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-equity-diversified-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "HDFC NIFTY50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty50-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Quant Teck Fund",
      link: "https://groww.in/mutual-funds/quant-teck-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-dividend-yield-plus-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bank of India Manufacturing & Infrastructure Fund",
      link: "https://groww.in/mutual-funds/boi-axa-manufacturing-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "HDFC Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-banking-and-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "LIC MF Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Quant Business Cycle Fund",
      link: "https://groww.in/mutual-funds/quant-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "ICICI Prudential ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-long-term-equity-fund-tax-saving-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Arbitrage Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-enhanced-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant BFSI Fund",
      link: "https://groww.in/mutual-funds/quant-bfsi-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Nippon India Consumption Fund",
      link: "https://groww.in/mutual-funds/nippon-india-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Bandhan Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/idfc-banking-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Tata India Consumer Fund",
      link: "https://groww.in/mutual-funds/tata-india-consumer-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "ICICI Prudential Income Optimizer Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-cautious-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Edelweiss Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/edelweiss-prudent-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Quant Dynamic Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/quant-dynamic-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Tata Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/tata-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Edelweiss NIFTY Large Mid Cap 250 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-large-midcap-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Multicap Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Nippon India Strategic Debt Fund",
      link: "https://groww.in/mutual-funds/nippon-india-strategic-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Navi Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/navi-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Axis NASDAQ 100 FoF Fund",
      link: "https://groww.in/mutual-funds/axis-nasdaq-100-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HSBC Multi Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "LIC MF Infrastructure Fund",
      link: "https://groww.in/mutual-funds/lic-mf-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "DSP Government Securities Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-government-securities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "UTI Mid Cap Fund",
      link: "https://groww.in/mutual-funds/uti-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Invesco India - Invesco EQQQ NASDAQ-100 ETF FoF Fund",
      link: "https://groww.in/mutual-funds/invesco-india-invesco-eqqq-nasdaq-100-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "ICICI Prudential Bharat Consumption Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-bharat-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Bandhan Infrastructure Fund",
      link: "https://groww.in/mutual-funds/idfc-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Kotak Long Duration Fund",
      link: "https://groww.in/mutual-funds/kotak-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Nippon India Income Fund",
      link: "https://groww.in/mutual-funds/nippon-india-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Baroda BNP Paribas Small Cap Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Quant Tax Plan Fund",
      link: "https://groww.in/mutual-funds/quant-tax-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "ICICI Prudential Focused Equity Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-select-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Tata Money Market Fund",
      link: "https://groww.in/mutual-funds/tata-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life NASDAQ 100 FOF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nasdaq-100-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Tata Equity PE Fund",
      link: "https://groww.in/mutual-funds/tata-equity-pe-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Nippon India Value Fund",
      link: "https://groww.in/mutual-funds/nippon-india-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Nippon India Nifty 50 Value 20 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-50-value-20-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Canara Robeco Manufacturing Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-manufacturing-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Invesco India Contra Fund",
      link: "https://groww.in/mutual-funds/invesco-india-contra-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Arbitrage Fund",
      link: "https://groww.in/mutual-funds/uti-spread-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "JM Value Fund",
      link: "https://groww.in/mutual-funds/jm-basic-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "ICICI Prudential Short Term Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Franklin India Pension Fund",
      link: "https://groww.in/mutual-funds/franklin-india-pension-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "SBI Liquid Fund",
      link: "https://groww.in/mutual-funds/sbi-premier-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Nippon India Nifty AAA PSU Bond Plus SDL - Sep 2026 Maturity 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-aaa-psu-bond-plus-sdl-sep-2026-maturity-50:50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "WhiteOak Capital Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-large-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Parag Parikh Arbitrage Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "ICICI Prudential Business Cycle Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Income Fund",
      link: "https://groww.in/mutual-funds/hdfc-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Axis Focused 25 Fund",
      link: "https://groww.in/mutual-funds/axis-focused-25-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Tata Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/tata-flexicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "ITI Small Cap Fund",
      link: "https://groww.in/mutual-funds/iti-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Axis Nifty IT Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-it-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Axis Nifty Midcap 50 Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-midcap-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential All Seasons Bond Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-long-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential India Equity FOF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-india-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Tata Large Cap Fund",
      link: "https://groww.in/mutual-funds/tata-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Mirae Asset Emerging Bluechip Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-emerging-bluechip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Kotak India EQ Contra Fund",
      link: "https://groww.in/mutual-funds/kotak-classic-equity-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "DSP Healthcare Fund",
      link: "https://groww.in/mutual-funds/dsp-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HDFC Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/hdfc-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HDFC Multi Asset Fund",
      link: "https://groww.in/mutual-funds/hdfc-multiple-yield-fund-plan-2005-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Canara Robeco Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-balance-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Edelweiss Technology Fund",
      link: "https://groww.in/mutual-funds/edelweiss-technology-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Samco Active Momentum Fund",
      link: "https://groww.in/mutual-funds/samco-active-momentum-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/samco_groww.png",
    },
    {
      name: "Sundaram Consumption Fund",
      link: "https://groww.in/mutual-funds/sundaram-rural-india-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Union Small Cap Fund",
      link: "https://groww.in/mutual-funds/union-small-and-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Tata Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/tata-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Navi Nifty Bank Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-bank-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Baroda BNP Paribas Arbitrage Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Mahindra Manulife Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "ITI Mid Cap Fund",
      link: "https://groww.in/mutual-funds/iti-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Sundaram Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/sundaram-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Kotak Nifty Smallcap 50 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-smallcap-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential FMCG Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-fmcg-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Nifty IT Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-it-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Tata Business Cycle Fund",
      link: "https://groww.in/mutual-funds/tata-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "HSBC Midcap Fund",
      link: "https://groww.in/mutual-funds/hsbc-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "DSP US Treasury FoF Fund",
      link: "https://groww.in/mutual-funds/dsp-us-treasury-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "SBI S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/sbi-s-p-bse-sensex-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/tata-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Mirae Asset Great Consumer Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-great-consumer-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Axis Liquid Direct Fund",
      link: "https://groww.in/mutual-funds/axis-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Nippon India Multi Asset Fund",
      link: "https://groww.in/mutual-funds/nippon-india-multi-asset-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Aditya Birla Sun Life US Treasury 3-10 year Bond ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-us-treasury-3-10-year-bond-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "LIC MF Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-large-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Mirae Asset Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Small Cap Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-small-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Nippon India Liquid Fund",
      link: "https://groww.in/mutual-funds/nippon-india-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Quantum Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/quantum-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "LIC MF Children's Gift Fund",
      link: "https://groww.in/mutual-funds/lic-mf-childrens-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Frontline Equity Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-frontline-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "SBI International Access - US Equity FoF Fund",
      link: "https://groww.in/mutual-funds/sbi-international-access-us-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Edelweiss Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/edelweiss-absolute-return-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Healthcare Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Sundaram Mid Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-select-midcap-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "ICICI Prudential Asset Allocator Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-moderate-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Helios Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/helios-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/helios_groww.png",
    },
    {
      name: "Invesco India Mid Cap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Edelweiss Greater China Equity Off-shore Fund",
      link: "https://groww.in/mutual-funds/edelweiss-greater-china-equity-offshore-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Multi-Cap Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "UTI Large Cap Fund",
      link: "https://groww.in/mutual-funds/uti-unit-scheme-1986-mastershare-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Nippon India ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/nippon-india-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Groww Liquid Direct Fund",
      link: "https://groww.in/mutual-funds/groww-liquid-direct-fund-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Old Bridge Focused Equity Fund",
      link: "https://groww.in/mutual-funds/old-bridge-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/old_groww.png",
    },
    {
      name: "Kotak Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/kotak-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "DSP Midcap Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-small-and-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HDFC Non-Cyclical Consumer Fund",
      link: "https://groww.in/mutual-funds/hdfc-non-cyclical-consumer-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "360 ONE Balanced Hybrid Fund",
      link: "https://groww.in/mutual-funds/360-one-balanced-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Navi Nifty India Manufacturing Index Fund",
      link: "https://groww.in/mutual-funds/navi-nifty-india-manufacturing-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "WhiteOak Capital Mid Cap Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Bank of India Multi Cap Fund",
      link: "https://groww.in/mutual-funds/bank-of-india-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Nippon India Nifty Alpha Low Volatility 30 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-alpha-low-volatility-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-regular-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Invesco India Financial Services Fund",
      link: "https://groww.in/mutual-funds/invesco-india-banking-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "JM Large Cap Fund",
      link: "https://groww.in/mutual-funds/jm-equity-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Nippon India US Equity Opportunities Fund",
      link: "https://groww.in/mutual-funds/nippon-india-us-equity-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Kotak Healthcare Fund",
      link: "https://groww.in/mutual-funds/kotak-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Motilal Oswal Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-focused-multicap-35-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "IDBI Small Cap Fund",
      link: "https://groww.in/mutual-funds/idbi-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Edelweiss US Technology Equity FoF Fund",
      link: "https://groww.in/mutual-funds/edelweiss-us-technology-equity-fund-of-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Franklin India Feeder Franklin US Opportunities Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-india-feeder-franklin-us-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Kotak Equity Savings Fund",
      link: "https://groww.in/mutual-funds/kotak-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "PGIM India Small Cap Fund",
      link: "https://groww.in/mutual-funds/pgim-india-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Parag Parikh Tax Saver Fund",
      link: "https://groww.in/mutual-funds/parag-parikh-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/ppfas_groww.png",
    },
    {
      name: "HDFC Nifty 100 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-100-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "NJ Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/nj-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/nj_groww.png",
    },
    {
      name: "Bank of India Bluechip Fund",
      link: "https://groww.in/mutual-funds/boi-axa-bluechip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Axis Overnight Fund",
      link: "https://groww.in/mutual-funds/axis-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HSBC Value Fund",
      link: "https://groww.in/mutual-funds/hsbc-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Sundaram Small Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-smile-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Low Duration Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-cash-manager-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Edelweiss Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-equity-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "ICICI Prudential Gilt Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-long-term-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Midcap Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Edelweiss Nifty Smallcap 250 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-smallcap-250-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "HDFC Liquid Fund",
      link: "https://groww.in/mutual-funds/hdfc-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Union Liquid Fund",
      link: "https://groww.in/mutual-funds/union-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Pharma & Healthcare Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-pharma-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Infrastructure Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-infrastructure-fund-plan-a-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Tata Focused Equity Fund",
      link: "https://groww.in/mutual-funds/tata-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Tata Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/tata-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Bandhan Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/bandhan-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "SBI Magnum Global Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-global-fund-94-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Pharma Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-pharma-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Franklin India Bluechip Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-india-bluechip-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Edelweiss Equity Savings Fund",
      link: "https://groww.in/mutual-funds/edelweiss-equity-savings-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "UTI Innovation Fund",
      link: "https://groww.in/mutual-funds/uti-innovation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Axis Arbitrage Fund",
      link: "https://groww.in/mutual-funds/axis-enhanced-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Axis S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/axis-s-p-bse-sensex-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "DSP Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/dsp-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "ICICI Prudential Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-ultra-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Franklin India Focused Equity Fund",
      link: "https://groww.in/mutual-funds/franklin-india-high-growth-companies-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Bandhan Retirement Fund",
      link: "https://groww.in/mutual-funds/bandhan-retirement-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Axis Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Tata Nifty SDL Plus AAA PSU Bond Dec 2027 60:40 Index Fund",
      link: "https://groww.in/mutual-funds/tata-nifty-sdl-plus-aaa-psu-bond-dec-2027-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Franklin India Opportunities Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-india-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "SBI Long Duration Fund",
      link: "https://groww.in/mutual-funds/sbi-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bandhan Nifty200 Momentum 30 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-nifty200-momentum-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "ICICI Prudential Child Care Gift Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-child-care-plan-direct-gift-plan",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "TRUSTMF Banking & PSU Fund",
      link: "https://groww.in/mutual-funds/trustmf-banking-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "HSBC Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/hsbc-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Groww Short Duration Fund",
      link: "https://groww.in/mutual-funds/groww-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Navi Large & Midcap Fund",
      link: "https://groww.in/mutual-funds/navi-large-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Bandhan Nifty Alpha 50 Index Fund",
      link: "https://groww.in/mutual-funds/bandhan-nifty-alpha-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bandhan_groww.png",
    },
    {
      name: "Franklin India Prima Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-india-prima-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "HDFC Credit Risk Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-corporate-debt-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Passive Multi-Asset FoF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-passive-multi-asset-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Navi ELSS Tax Saver Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/navi-elss-tax-saver-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Nippon India Focused Equity Fund",
      link: "https://groww.in/mutual-funds/nippon-india-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Bandhan Nifty IT Index Fund",
      link: "https://groww.in/mutual-funds/bandhan-nifty-it-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "ICICI Prudential Regular Savings Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-regular-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Edelweiss MSCI India Domestic & World Healthcare 45 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-msci-india-domestic-world-healthcare-45-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI Magnum COMMA Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-comma-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Nifty G-Sec Dec 2029 Index Fund",
      link: "https://groww.in/mutual-funds/tata-nifty-g-sec-dec-2029-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "ICICI Prudential Credit Risk Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-credit-risk-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Bandhan Long Duration Fund",
      link: "https://groww.in/mutual-funds/bandhan-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Franklin India Technology Fund",
      link: "https://groww.in/mutual-funds/franklin-infotech-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "UTI Nifty Midcap 150 Quality 50 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-midcap-150-quality-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "JM Midcap Fund",
      link: "https://groww.in/mutual-funds/jm-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Focused Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-top-100-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Axis Corporate Debt Fund",
      link: "https://groww.in/mutual-funds/axis-corporate-debt-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Axis CRISIL IBX SDL June 2034 Debt Index Fund",
      link: "https://groww.in/mutual-funds/axis-crisil-ibx-sdl-june-2034-debt-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC Business Cycle Fund",
      link: "https://groww.in/mutual-funds/hdfc-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Union Midcap Fund",
      link: "https://groww.in/mutual-funds/union-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Baroda BNP Paribas Innovation Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-innovation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Mirae Asset Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "ICICI Prudential Equity Savings Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-equity-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "WhiteOak Capital Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Motilal Oswal Nifty Bank Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-bank-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Kotak Quant Fund",
      link: "https://groww.in/mutual-funds/kotak-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Templeton India Equity Income Fund",
      link: "https://groww.in/mutual-funds/templeton-india-equity-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Nippon India Taiwan Equity Fund",
      link: "https://groww.in/mutual-funds/nippon-india-taiwan-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Strategic Metal and Energy Equity FoF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-strategic-metal-and-energy-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Bandhan Transportation and Logistics Fund",
      link: "https://groww.in/mutual-funds/idfc-transportation-and-logistics-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Government Securities Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-gppfp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Axis US Treasury Dynamic Bond ETF FoF Fund",
      link: "https://groww.in/mutual-funds/axis-us-treasury-dynamic-bond-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Bank of India Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/bank-of-india-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "HDFC Developed World Indexes FoF Fund",
      link: "https://groww.in/mutual-funds/hdfc-developed-world-indexes-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Kotak Nifty Financial Services Ex-Bank Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-financial-services-ex-bank-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "JM Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/jm-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "SBI Retirement Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-retirement-benefit-fund-aggressive-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bajaj Finserv Banking and PSU Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-banking-and-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "UTI Short Duration Fund",
      link: "https://groww.in/mutual-funds/uti-short-term-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Groww Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/groww-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/indiabulls_groww.png",
    },
    {
      name: "Mirae Asset Liquid Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty Midcap 150 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-midcap-150-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "PGIM India Global Select Real Estate Securities FoF Fund",
      link: "https://groww.in/mutual-funds/pgim-india-global-select-real-estate-securities-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "SBI Equity Savings Fund",
      link: "https://groww.in/mutual-funds/sbi-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Edelweiss Large Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-top-100-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Sundaram Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-equity-multiplier-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "HDFC S&P BSE 500 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-s-p-bse-500-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Income Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-i-come-plus-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Samco Dynamic Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/samco-dynamic-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/samco_groww.png",
    },
    {
      name: "ICICI Prudential Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Nippon India Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/nippon-india-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Franklin India ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/franklin-india-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Kotak Equity Arbitrage Fund",
      link: "https://groww.in/mutual-funds/kotak-equity-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Bandhan Large Cap Fund",
      link: "https://groww.in/mutual-funds/idfc-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "WhiteOak Capital Multi Cap Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Pure Value Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-pure-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quantum ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/quantum-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "360 ONE FlexiCap Fund",
      link: "https://groww.in/mutual-funds/360-one-flexicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Tata Housing Opportunities Fund",
      link: "https://groww.in/mutual-funds/tata-housing-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Global Excellence Equity FoF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-global-excellence-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Templeton India Value Fund",
      link: "https://groww.in/mutual-funds/templeton-india-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Franklin India Dynamic Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/franklin-india-dynamic-pe-ratio-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "360 ONE Quant Fund",
      link: "https://groww.in/mutual-funds/iifl-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Baroda BNP Paribas Large Cap Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "UTI Retirement Fund",
      link: "https://groww.in/mutual-funds/uti-retirement-benefit-pension-fund-rbp-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "SBI Magnum Children's Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-children-benefit-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bandhan Core Equity Fund",
      link: "https://groww.in/mutual-funds/idfc-classic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "SBI Magnum Constant Maturity Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-gilt-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Baroda BNP Paribas Midcap Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-midcap-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "UTI Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/uti-floating-rate-fund-stp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Axis Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HSBC Equity Savings Fund",
      link: "https://groww.in/mutual-funds/hsbc-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Bandhan Tax Advantage (ELSS) Fund",
      link: "https://groww.in/mutual-funds/idfc-tax-advantage-elss-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Samco Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/samco-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/samco_groww.png",
    },
    {
      name: "TRUSTMF Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/trustmf-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "Edelweiss Liquid Fund",
      link: "https://groww.in/mutual-funds/edelweiss-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "UTI Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/uti-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "UTI Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/uti-large-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Axis Greater China Equity FoF Fund",
      link: "https://groww.in/mutual-funds/axis-greater-china-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Union Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/union-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Alpha Low Volatility 30 ETF FOF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-alpha-low-vol-30-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Kotak Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/kotak-balance-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Mahindra Manulife Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/mahindra-hybrid-equity-nivesh-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Kotak Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "UTI ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/uti-long-term-equity-fund-tax-saving-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Sundaram Large Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-bluechip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "DSP Equity Opportunities Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Invesco India Multicap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-mid-n-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Medium to Long Duration Fund",
      link: "https://groww.in/mutual-funds/uti-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life US Treasury 1-3 year Bond ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-us-treasury-1-3-year-bond-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Canara Robeco Consumer Trends Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-force-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "DSP Global Innovation FoF Fund",
      link: "https://groww.in/mutual-funds/dsp-global-innovation-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Sundaram Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "WhiteOak Capital Pharma and Healthcare Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-pharma-and-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "UTI NIFTY50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty50-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Motilal Oswal Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Aditya Birla Sun Life India GenNext Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-india-gennext-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HDFC NIFTY 100 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-100-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HSBC Focused Fund",
      link: "https://groww.in/mutual-funds/hsbc-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Motilal Oswal Developed Market Ex US ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-developed-market-ex-us-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Nippon India Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/nippon-india-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "PGIM India ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/pgim-india-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "UTI Healthcare Fund",
      link: "https://groww.in/mutual-funds/uti-pharma-and-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "UTI Liquid Fund",
      link: "https://groww.in/mutual-funds/uti-liquid-cash-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Nippon India Passive Flexicap FoF Fund",
      link: "https://groww.in/mutual-funds/nippon-india-passive-flexicap-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Axis Business Cycles Fund",
      link: "https://groww.in/mutual-funds/axis-business-cycles-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential Thematic Advantage Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-very-aggressive-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HSBC Large and Mid Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-large-and-mid-cap-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Taurus Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/taurus-nifty-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "SBI Overnight Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-insta-cash-fund-liquid-floater-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential Nifty Bank Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-bank-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "ICICI Prudential Housing Opportunities Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-housing-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "DSP Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/dsp-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "ICICI Prudential Nifty50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty50-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Equity Savings Fund",
      link: "https://groww.in/mutual-funds/hdfc-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Nippon India Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/nippon-india-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Nippon India Arbitrage Fund",
      link: "https://groww.in/mutual-funds/nippon-india-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Baroda BNP Paribas Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Bandhan Government Securities Investment Plan Fund",
      link: "https://groww.in/mutual-funds/idfc-g-sec-fund-investment-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Nippon India Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/nippon-india-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Edelweiss Gold and Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/edelweiss-gold-and-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Navi S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/navi-s-p-bse-sensex-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Tata Nifty G-Sec Dec 2026 Index Fund",
      link: "https://groww.in/mutual-funds/tata-nifty-g-sec-dec-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Kotak Multi Asset Allocator FoF - Dynamic Fund",
      link: "https://groww.in/mutual-funds/kotak-asset-allocator-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Quantum Multi Asset Fund",
      link: "https://groww.in/mutual-funds/quantum-multi-asset-fund-of-funds-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Nippon India Retirement Fund",
      link: "https://groww.in/mutual-funds/nippon-india-retirement-fund-wealth-creation-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Bandhan Financial Services Fund",
      link: "https://groww.in/mutual-funds/bandhan-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "HDFC Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/hdfc-retirement-savings-fund-hybrid-equity-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ITI Pharma and Healthcare Fund",
      link: "https://groww.in/mutual-funds/iti-pharma-and-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Quantum Long Term Equity Value Fund",
      link: "https://groww.in/mutual-funds/quantum-long-term-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Nippon India Japan Equity Fund",
      link: "https://groww.in/mutual-funds/nippon-india-japan-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX Gilt April 2033 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-gilt-april-2033-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Canara Robeco Income Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-i-come-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "SBI Arbitrage Opportunities Fund",
      link: "https://groww.in/mutual-funds/sbi-arbitrage-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Mirae Asset Hang Seng TECH ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-hang-seng-tech-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Gold Direct Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-gold-direct-fund-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "ITI Multi Cap Fund",
      link: "https://groww.in/mutual-funds/iti-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "TRUSTMF Money Market Fund",
      link: "https://groww.in/mutual-funds/trustmf-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "Union Business Cycle Fund",
      link: "https://groww.in/mutual-funds/union-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Navi Overnight Fund",
      link: "https://groww.in/mutual-funds/navi-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Kotak Manufacture in India Fund",
      link: "https://groww.in/mutual-funds/kotak-manufacture-in-india-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Union Multicap Fund",
      link: "https://groww.in/mutual-funds/union-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Mirae Asset Focused Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Quantum ESG Best In Class Strategy Fund",
      link: "https://groww.in/mutual-funds/quantum-esg-best-in-class-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "HSBC Asia Pacific (Ex Japan) Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/hsbc-asia-pacific-ex-japan-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Bandhan Midcap Fund",
      link: "https://groww.in/mutual-funds/idfc-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "LIC MF Gold ETF FoF Fund",
      link: "https://groww.in/mutual-funds/lic-mf-gold-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Canara Robeco Liquid Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-liquid-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "DSP Dynamic Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-dynamic-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Mahindra Manulife Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/mahindra-ultra-short-term-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "LIC MF Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/lic-mf-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "360 ONE ELSS Tax Saver Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/360-one-elss-tax-saver-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Invesco India Largecap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-business-leaders-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Axis Value Fund",
      link: "https://groww.in/mutual-funds/axis-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Mahindra Manulife Focused Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-focused-equity-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "DSP World Mining Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-world-mining-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Invesco India Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Kotak Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/kotak-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HDFC MNC Fund",
      link: "https://groww.in/mutual-funds/hdfc-mnc-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HDFC Capital Builder Value Fund",
      link: "https://groww.in/mutual-funds/hdfc-capital-builder-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "IDBI Gold Fund",
      link: "https://groww.in/mutual-funds/idbi-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Baroda BNP Paribas Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/baroda-dynamic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Mirae Asset Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Bajaj Finserv Arbitrage Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "HDFC Low Duration Fund",
      link: "https://groww.in/mutual-funds/hdfc-cash-management-fund-treasury-advantage-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Mirae Asset Overnight Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Quant Overnight Fund",
      link: "https://groww.in/mutual-funds/quant-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "PGIM India Global Equity Opportunities Fund",
      link: "https://groww.in/mutual-funds/pgim-india-global-equity-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Tata Liquid Fund",
      link: "https://groww.in/mutual-funds/tata-liquid-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Edelweiss Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/edelweiss-economic-resurgence-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI Magnum Medium Duration Fund",
      link: "https://groww.in/mutual-funds/sbi-regular-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "UTI Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/uti-wealth-builder-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Sundaram Short Duration Fund",
      link: "https://groww.in/mutual-funds/sundaram-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Bank of India Overnight Fund",
      link: "https://groww.in/mutual-funds/boi-axa-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "DSP Top 100 Equity Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-top-100-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "ITI Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/iti-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "HDFC Housing Opportunities Fund",
      link: "https://groww.in/mutual-funds/hdfc-housing-opportunities-fund-series-1-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Motilal Oswal Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "ICICI Prudential Overnight Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Dynamic PE Ratio FoF Fund",
      link: "https://groww.in/mutual-funds/hdfc-dynamic-pe-ratio-fund-of-funds-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HSBC Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/hsbc-banking-and-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Kotak Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "UTI Credit Risk Fund",
      link: "https://groww.in/mutual-funds/uti-i-come-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bandhan Multi Cap Fund",
      link: "https://groww.in/mutual-funds/idfc-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Mahindra Manulife Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-flexi-cap-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "SBI Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/sbi-corporate-bond-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Bal Bhavishya Yojna Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-bal-bhavishya-yojna-wealth-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Mahindra Manulife ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "DSP Arbitrage Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Dynamic Bond Retail Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Mahindra Manulife Business Cycle Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Mirae Asset S&P 500 Top 50 ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-s-p-500-top-50-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Edelweiss Arbitrage Fund",
      link: "https://groww.in/mutual-funds/edelweiss-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI Magnum Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-insta-cash-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Baroda BNP Paribas India Consumption Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-india-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "DSP Nifty Midcap 150 Quality 50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-midcap-150-quality-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Kotak Focused Equity Fund",
      link: "https://groww.in/mutual-funds/kotak-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Nippon India Money Market Fund",
      link: "https://groww.in/mutual-funds/nippon-india-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "LIC MF Multi Cap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "UTI Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/uti-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Quant Gilt Fund",
      link: "https://groww.in/mutual-funds/quant-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty 50 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-50-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Franklin India Feeder - Templeton European Opportunities Fund",
      link: "https://groww.in/mutual-funds/ft-india-feeder-franklin-european-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Baroda BNP Paribas NIFTY 50 Index Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Helios Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/helios-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/helios_groww.png",
    },
    {
      name: "Sundaram Services Fund",
      link: "https://groww.in/mutual-funds/sundaram-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Kotak Pioneer Fund",
      link: "https://groww.in/mutual-funds/kotak-pioneer-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "WhiteOak Capital Balanced Hybrid Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-balanced-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Invesco India - Invesco Global Equity Income FoF Fund",
      link: "https://groww.in/mutual-funds/invesco-india-global-equity-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/uti-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Manufacturing Equity Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-manufacturing-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "NJ ELSS Tax Saver Scheme Fund",
      link: "https://groww.in/mutual-funds/nj-elss-tax-saver-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/nj_groww.png",
    },
    {
      name: "Mirae Asset Arbitrage Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "TRUSTMF Liquid Fund",
      link: "https://groww.in/mutual-funds/trust-mf-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "Axis Quant Fund",
      link: "https://groww.in/mutual-funds/axis-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "UTI Infrastructure Fund",
      link: "https://groww.in/mutual-funds/uti-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Canara Robeco Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Union Innovation & Opportunities Fund",
      link: "https://groww.in/mutual-funds/union-innovation-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Kotak Global Innovation FoF Fund",
      link: "https://groww.in/mutual-funds/kotak-global-innovation-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Bank of India Large & Mid Cap Equity Fund",
      link: "https://groww.in/mutual-funds/boi-axa-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "DSP Gold ETF FoF Fund",
      link: "https://groww.in/mutual-funds/dsp-gold-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "UTI S&P BSE Sensex Index Fund",
      link: "https://groww.in/mutual-funds/uti-sensex-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "SBI Magnum Equity ESG Fund",
      link: "https://groww.in/mutual-funds/sbi-magnum-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Sundaram Low Duration Fund",
      link: "https://groww.in/mutual-funds/sundaram-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Axis Long Term Equity Fund",
      link: "https://groww.in/mutual-funds/axis-long-term-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Equity Advantage Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HSBC Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-india-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Short Term Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-short-term-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HDFC Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/hdfc-medium-term-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Tata Short Term Bond Fund",
      link: "https://groww.in/mutual-funds/tata-short-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Invesco India Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/invesco-india-large-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "HDFC Dynamic Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-high-interest-fund-dynamic-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Mahindra Manulife Large Cap Fund",
      link: "https://groww.in/mutual-funds/mahindra-pragati-bluechip-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Money Manager Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-floating-rate-fund-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Active Debt Multi Manager FoF Scheme Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-active-debt-multi-manager-fof-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Invesco India Nifty G-sec Sep 2032 Index Fund",
      link: "https://groww.in/mutual-funds/invesco-india-nifty-g-sec-sep-2032-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Axis Global Innovation FoF Fund",
      link: "https://groww.in/mutual-funds/axis-global-innovation-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "TRUSTMF Overnight Fund",
      link: "https://groww.in/mutual-funds/trust-mf-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "DSP World Energy Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-world-energy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "SBI ESG Exclusionary Strategy Fund",
      link: "https://groww.in/mutual-funds/sbi-esg-exclusionary-strategy-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Quantum Gold Savings Fund",
      link: "https://groww.in/mutual-funds/quantum-gold-savings-fund-Direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Motilal Oswal Focused Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-focused-25-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Tata CRISIL-IBX Gilt Index - April 2026 Index Fund",
      link: "https://groww.in/mutual-funds/tata-crisil-ibx-gilt-index-april-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Nippon India Vision Fund",
      link: "https://groww.in/mutual-funds/nippon-india-vision-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Long Term Bond Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HSBC Consumption Fund",
      link: "https://groww.in/mutual-funds/hsbc-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "DSP US Flexible Equity Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-us-flexible-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Retirement Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-retirement-fund-the-30s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "SBI Equity Minimum Variance Fund",
      link: "https://groww.in/mutual-funds/sbi-equity-minimum-variance-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "UTI Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/uti-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Sundaram Focused Fund",
      link: "https://groww.in/mutual-funds/sundaram-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty SDL Plus PSU Bond Sep 2026 60:40 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-sdl-plus-psu-bond-sep-2026-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "ICICI Prudential Equity Arbitrage Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-equity-arbitrage-fund-direct-gth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Samco ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/samco-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/samco_groww.png",
    },
    {
      name: "Union Retirement Fund",
      link: "https://groww.in/mutual-funds/union-retirement-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Nippon India Short Term Fund",
      link: "https://groww.in/mutual-funds/nippon-india-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Invesco India ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/invesco-india-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Bandhan Government Securities Fund",
      link: "https://groww.in/mutual-funds/idfc-government-securities-fund-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Bandhan US Treasury Bond 0-1 year FoF Fund",
      link: "https://groww.in/mutual-funds/idfc-us-treasury-bond-0-1-year-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "DSP Government Securities Fund",
      link: "https://groww.in/mutual-funds/dsp-government-securities-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Nippon India Nivesh Lakshya Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nivesh-lakshya-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "NJ Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/nj-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/nj_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Regular Savings Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-mip-ii-wealth-25-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Sundaram Multi Cap Fund",
      link: "https://groww.in/mutual-funds/sundaram-multi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "SBI CPSE Bond Plus SDL Sep 2026 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/sbi-cpse-bond-plus-sdl-sep-2026-50:50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bajaj Finserv Money Market Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "Principal Small Cap Fund",
      link: "https://groww.in/mutual-funds/principal-small-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/principal_groww.png",
    },
    {
      name: "IDBI India Top 100 Equity Fund",
      link: "https://groww.in/mutual-funds/idbi-india-top-100-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Motilal Oswal Asset Allocation Passive FoF - Aggressive Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-asset-allocation-passive-fund-of-fund-aggressive",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "DSP World Agriculture Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-world-agriculture-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HDFC Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/hdfc-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "ICICI Prudential Retirement Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-retirement-fund-hybrid-aggressive-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "DSP Liquidity Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-liquidity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Axis Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/axis-retirement-savings-fund-aggressive-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "UTI Value Fund",
      link: "https://groww.in/mutual-funds/uti-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "HSBC Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/hsbc-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Baroda BNP Paribas Value Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Tata Treasury Advantage Fund",
      link: "https://groww.in/mutual-funds/tata-floater-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "TRUSTMF Short Duration Fund",
      link: "https://groww.in/mutual-funds/trustmf-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "UTI Equity Savings Fund",
      link: "https://groww.in/mutual-funds/uti-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Nippon India Nifty AAA CPSE Bond Plus SDL - Apr 2027 Maturity 60:40 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-aaa-cpse-bond-plus-sdl-apr-2027-maturity-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Kotak S&P BSE Housing Index Fund",
      link: "https://groww.in/mutual-funds/kotak-s-p-bse-housing-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "PGIM India Overnight Fund",
      link: "https://groww.in/mutual-funds/pgim-india-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "DSP Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Motilal Oswal S&P BSE Financials ex Bank 30 Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-s-p-bse-financials-ex-bank-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "UTI Gold ETF FoF Fund",
      link: "https://groww.in/mutual-funds/uti-gold-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Tata India Tax Savings Fund",
      link: "https://groww.in/mutual-funds/tata-india-tax-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Tata Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/tata-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "WhiteOak Capital ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Quantum Nifty 50 ETF FoF Fund",
      link: "https://groww.in/mutual-funds/quantum-nifty-50-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "SBI Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/sbi-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "SBI Magnum Low Duration Fund",
      link: "https://groww.in/mutual-funds/sbi-ultra-short-term-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "WhiteOak Capital Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Kotak Consumption Fund",
      link: "https://groww.in/mutual-funds/kotak-consumption-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HSBC Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/hsbc-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Business Cycle Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Nippon India Tax Saver (ELSS) Fund",
      link: "https://groww.in/mutual-funds/nippon-india-tax-saver-elss-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Axis Short Term Direct Fund",
      link: "https://groww.in/mutual-funds/axis-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Sundaram Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/sundaram-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "DSP Value Fund",
      link: "https://groww.in/mutual-funds/dsp-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Navi Liquid Fund",
      link: "https://groww.in/mutual-funds/navi-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "HDFC Money Market Fund",
      link: "https://groww.in/mutual-funds/hdfc-cash-management-fund-savings-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "WhiteOak Capital Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "IDBI Credit Risk Fund",
      link: "https://groww.in/mutual-funds/idbi-corporate-debt-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "ICICI Prudential Passive Strategy Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-advisor-series-long-term-savings-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/hdfc-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Axis Special Situations Fund",
      link: "https://groww.in/mutual-funds/axis-special-situations-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "DSP Equity & Bond Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Franklin India Government Securities Fund",
      link: "https://groww.in/mutual-funds/franklin-india-gsf-ltp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Kotak Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/kotak-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Edelweiss Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/edelweiss-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Canara Robeco Focused Equity Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Tata Gilt Securities Fund",
      link: "https://groww.in/mutual-funds/tata-gilt-securities-fund-plan-a-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Franklin India Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/franklin-india-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "ICICI Prudential Nifty 100 Low Volatility 30 ETF FOF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-low-vol-30-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Edelweiss Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "HDFC Floating Rate Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-floating-rate-i-come-fund-short-term-fund-wp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Nippon India Overnight Fund",
      link: "https://groww.in/mutual-funds/nippon-india-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Floating Interest Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Sundaram Infrastructure Advantage Fund",
      link: "https://groww.in/mutual-funds/sundaram-infrastructure-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "ITI ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/iti-long-term-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Nippon India Credit Risk Fund",
      link: "https://groww.in/mutual-funds/nippon-india-credit-risk-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "SBI Floating Rate Debt Fund",
      link: "https://groww.in/mutual-funds/sbi-floating-rate-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Nippon India Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/nippon-india-equity-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Baroda BNP Paribas Banking & PSU Bond Fund",
      link: "https://groww.in/mutual-funds/baroda-banking-psu-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "ICICI Prudential Nifty PSU Bond Plus SDL Sep 2027 40:60 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-psu-bond-plus-sdl-40:60-index-fund-sep-2027-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Tata Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/tata-retirement-savings-fund-moderate-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Kotak Business Cycle Fund",
      link: "https://groww.in/mutual-funds/kotak-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Canara Robeco Value Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "LIC MF Large Cap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "SBI Credit Risk Fund",
      link: "https://groww.in/mutual-funds/sbi-corporate-credit-risk-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "ICICI Prudential MNC Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-mnc-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Invesco India Gold ETF FoF Fund",
      link: "https://groww.in/mutual-funds/invesco-india-gold-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Axis Equity ETFs FoF Fund",
      link: "https://groww.in/mutual-funds/axis-equity-etfs-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Savings Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Financial Planning FoF Conservative Plan Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-financial-planning-fof-conservative-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Mirae Asset Tax Saver Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Sundaram Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/sundaram-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "360 ONE Liquid Fund",
      link: "https://groww.in/mutual-funds/iifl-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Baroda BNP Paribas Credit Risk Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-credit-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "360 ONE Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/iifl-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "HSBC Brazil Fund",
      link: "https://groww.in/mutual-funds/hsbc-brazil-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Sundaram Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/sundaram-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Quantum Liquid Fund",
      link: "https://groww.in/mutual-funds/quantum-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Bajaj Finserv Liquid Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "Bandhan Emerging Businesses Fund",
      link: "https://groww.in/mutual-funds/idfc-emerging-businesses-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "SBI Savings Fund",
      link: "https://groww.in/mutual-funds/sbi-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Tata Equity Savings Fund",
      link: "https://groww.in/mutual-funds/tata-regular-saving-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Bandhan Nifty100 Low Volatility 30 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-nifty100-low-volatility-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "UTI Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/uti-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Helios Overnight Fund",
      link: "https://groww.in/mutual-funds/helios-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/helios_groww.png",
    },
    {
      name: "Baroda BNP Paribas Short Duration Direct Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-short-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Union ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/union-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Kotak Liquid Fund",
      link: "https://groww.in/mutual-funds/kotak-liquid-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Mirae Asset Nifty India Manufacturing ETF FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nifty-india-manufacturing-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Axis Nifty AAA Bond Plus SDL Apr 2026 50:50 ETF FoF Fund",
      link: "https://groww.in/mutual-funds/axis-aaa-bond-plus-sdl-etf-2026-maturity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC Overnight Fund",
      link: "https://groww.in/mutual-funds/hdfc-cash-management-fund-call-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "WhiteOak Capital Large Cap Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "HSBC Small Cap Equity Fund",
      link: "https://groww.in/mutual-funds/hsbc-midcap-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "LIC MF Money Market Fund",
      link: "https://groww.in/mutual-funds/lic-mf-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "ICICI Prudential S&P BSE 500 ETF FOF Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-s-p-bse-500-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Axis Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/axis-triple-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Motilal Oswal Multi Asset Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-multi-asset-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Aditya Birla Sun Life ELSS Tax Relief 96 Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-tax-relief-96-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Baroda BNP Paribas Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bnp_groww.png",
    },
    {
      name: "UTI Focused Fund",
      link: "https://groww.in/mutual-funds/uti-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "IDBI Dividend Yield Fund",
      link: "https://groww.in/mutual-funds/idbi-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Baroda BNP Paribas ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Mirae Asset Equity Allocator FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-equity-allocator-fund-of-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "LIC MF Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/lic-mf-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Mirae Asset Nifty 100 ESG Sector Leaders FoF Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-esg-sector-leaders-fund-of-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "LIC MF Long Term Value Fund",
      link: "https://groww.in/mutual-funds/lic-mf-long-term-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Nippon India Gilt Securities Fund",
      link: "https://groww.in/mutual-funds/nippon-india-gilt-securities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Edelweiss Government Securities Fund",
      link: "https://groww.in/mutual-funds/edelweiss-govt-securities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "LIC MF Healthcare Fund",
      link: "https://groww.in/mutual-funds/lic-mf-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Special Opportunities Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-special-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Edelweiss Nifty 100 Quality 30 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-100-quality-30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Invesco India Growth Opportunities Fund",
      link: "https://groww.in/mutual-funds/invesco-india-growth-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Tata Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/tata-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Sundaram ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/sundaram-elss-tax-saver-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Sundaram Debt Oriented Hybrid Fund",
      link: "https://groww.in/mutual-funds/sundaram-monthly-i-come-plan-aggressive-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Union Large & Midcap Fund",
      link: "https://groww.in/mutual-funds/union-large-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "HSBC Large Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Motilal Oswal S&P BSE Low Volatility Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-s-p-bse-low-volatility-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Axis CRISIL IBX 70:30 CPSE Plus SDL April 2025 Index Fund",
      link: "https://groww.in/mutual-funds/axis-cpse-plus-sdl-2025-70:30-debt-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "IDBI Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/idbi-nifty-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Floating Rate Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-floating-rate-fund-ltp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Nippon India Quant Fund",
      link: "https://groww.in/mutual-funds/nippon-india-quant-fund-retail-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Axis Global Equity Alpha FoF Fund",
      link: "https://groww.in/mutual-funds/axis-global-equity-alpha-fund-of-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "SBI CRISIL IBX Gilt Index - June 2036 Fund",
      link: "https://groww.in/mutual-funds/sbi-crisil-ibx-gilt-index-june-2036-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Bandhan Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "ICICI Prudential Savings Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-flexible-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Invesco India - Invesco Global Consumer Trends FoF Fund",
      link: "https://groww.in/mutual-funds/invesco-india-invesco-global-consumer-trends-fund-of-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Low Duration Fund",
      link: "https://groww.in/mutual-funds/uti-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "JM ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/jm-tax-gain-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "ITI Large Cap Fund",
      link: "https://groww.in/mutual-funds/iti-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Bandhan Nifty 100 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-nifty-100-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Sundaram Equity Savings Fund",
      link: "https://groww.in/mutual-funds/sundaram-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "LIC MF Low Duration Fund",
      link: "https://groww.in/mutual-funds/lic-mf-savings-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "TRUSTMF Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/trust-mf-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "Aditya Birla Sun Life International Equity Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-international-equity-fund-plan-a-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "PGIM India Large Cap Fund",
      link: "https://groww.in/mutual-funds/pgim-india-large-cap-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Axis Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/axis-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Axis Silver FoF Fund",
      link: "https://groww.in/mutual-funds/axis-silver-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Taurus Discovery (Midcap) Fund",
      link: "https://groww.in/mutual-funds/taurus-discovery-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Axis Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/axis-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC Asset Allocator FoF Fund",
      link: "https://groww.in/mutual-funds/hdfc-asset-allocator-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "UTI S&P BSE Low Volatility Index Fund",
      link: "https://groww.in/mutual-funds/uti-s-p-bse-low-volatility-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Mahindra Manulife Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-balanced-advantage-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "TRUSTMF Short Term Fund",
      link: "https://groww.in/mutual-funds/trustmf-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "LIC  MFDividend Yield Fund",
      link: "https://groww.in/mutual-funds/lic-mfdividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Equity Hybrid '95 Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-balanced-95-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Nippon India Asset Allocator FoF Fund",
      link: "https://groww.in/mutual-funds/nippon-india-asset-allocator-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ITI Value Fund",
      link: "https://groww.in/mutual-funds/iti-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Bandhan Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/idfc-premier-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Edelweiss US Value Equity Offshore Fund",
      link: "https://groww.in/mutual-funds/edelweiss-us-value-equity-offshore-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "HSBC ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/hsbc-elss-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Global Excellence Equity FoF Retail Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-global-real-estate-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Baroda BNP Paribas Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "ICICI Prudential Money Market Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Nippon India Low Duration Fund",
      link: "https://groww.in/mutual-funds/nippon-india-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Shriram Multi Asset Allocation Fund",
      link: "https://groww.in/mutual-funds/shriram-multi-asset-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "HSBC Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/hsbc-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "HDFC Medium Term Debt Fund",
      link: "https://groww.in/mutual-funds/hdfc-high-interest-fund-short-term-plan-direct-growth-",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "UTI Banking & PSU Fund",
      link: "https://groww.in/mutual-funds/uti-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "HDFC Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/hdfc-retirement-savings-fund-hybrid-debt-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Axis ESG Integration Strategy Fund",
      link: "https://groww.in/mutual-funds/axis-esg-integration-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC Fixed Maturity Plan - 1141 Days - August 2018 (1) Fund",
      link: "https://groww.in/mutual-funds/hdfc-fixed-maturity-plan-august-2018-42-1-1141d-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Financial Planning FoF Moderate Plan Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-financial-planning-fof-prudent-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "SBI Retirement Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-retirement-benefit-fund-conservative-hybrid-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "LIC MF Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/lic-mf-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Tata Medium Term Fund",
      link: "https://groww.in/mutual-funds/tata-i-come-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Global Emerging Opportunities Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-global-commodities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bajaj Finserv Overnight Fund",
      link: "https://groww.in/mutual-funds/bajaj-finserv-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bajaj_groww.png",
    },
    {
      name: "ICICI Prudential Constant Maturity Gilt Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-constant-maturity-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Motilal Oswal Asset Allocation Passive FoF - Conservative Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-asset-allocation-passive-fund-of-fund-conservative",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Baroda BNP Paribas Multi Asset Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-multi-asset-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-treasury-optimizer-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Principal Emerging Bluechip Fund",
      link: "https://groww.in/mutual-funds/principal-emerging-bluechip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/principal_groww.png",
    },
    {
      name: "ITI Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/iti-banking-and-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "ICICI Prudential ESG Exclusionary Strategy Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-esg-exclusionary-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HSBC Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/hsbc-nifty-next-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "UTI Large & Mid Cap Fund",
      link: "https://groww.in/mutual-funds/uti-top-100-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "DSP Equity Savings Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HDFC Gilt Fund",
      link: "https://groww.in/mutual-funds/hdfc-gilt-fund-long-term-plan-direct-growth-",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Invesco India Nifty G-sec Jul 2027 Index Fund",
      link: "https://groww.in/mutual-funds/invesco-india-nifty-g-sec-jul-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Axis Long Duration Fund",
      link: "https://groww.in/mutual-funds/axis-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Navi Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/navi-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Kotak Low Duration Fund",
      link: "https://groww.in/mutual-funds/kotak-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential Medium Term Bond Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX 60:40 SDL+AAA PSU-Apr 2025 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-sdl-plus-aaa-psu-apr-2025-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "LIC MF ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/lic-mf-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Mirae Asset Nifty AAA PSU Bond Plus SDL Apr 2026 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nifty-aaa-psu-bond-plus-sdl-apr-2026-50:50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "SBI Fixed Maturity Plan - Series 5 (92 Days) Fund",
      link: "https://groww.in/mutual-funds/sbi-fixed-maturity-plan-(fmp)-series-5-(92-days)-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "UTI MNC Fund",
      link: "https://groww.in/mutual-funds/uti-mnc-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bandhan US Equity FoF Fund",
      link: "https://groww.in/mutual-funds/idfc-us-equity-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Franklin Asian Equity Direct Fund",
      link: "https://groww.in/mutual-funds/franklin-asian-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Kotak Silver ETF FoF Fund",
      link: "https://groww.in/mutual-funds/kotak-silver-etf-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Kotak Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/kotak-flexi-debt-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Bank of India Liquid Fund",
      link: "https://groww.in/mutual-funds/boi-axa-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "ICICI Prudential Quant Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Kotak Nifty SDL Apr 2032 Top 12 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-apr-2032-top-12-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ITI Focused Equity Fund",
      link: "https://groww.in/mutual-funds/iti-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Canara Robeco Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-banking-and-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Tata Quant Fund",
      link: "https://groww.in/mutual-funds/tata-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Long Duration Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Navi Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/navi-conservative-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "ITI Banking and PSU Fund",
      link: "https://groww.in/mutual-funds/iti-banking-and-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Tata Floating Rate Fund",
      link: "https://groww.in/mutual-funds/tata-floating-rate-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Motilal Oswal S&P BSE Quality Index Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-s-p-bse-quality-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Kotak Low Duration Fund",
      link: "https://groww.in/mutual-funds/kotak-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Sundaram Select Focus Fund",
      link: "https://groww.in/mutual-funds/sundaram-select-focus-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Aditya Birla Sun Life MNC Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-mnc-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Kotak Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/kotak-banking-and-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Tata Overnight Fund",
      link: "https://groww.in/mutual-funds/tata-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Multi - Index FoF Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-multi-index-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Credit Risk Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "DSP Quant Fund",
      link: "https://groww.in/mutual-funds/dsp-quant-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "360 ONE ELSS Nifty 50 Tax Saver Index Fund",
      link: "https://groww.in/mutual-funds/iifl-elss-nifty-50-tax-saver-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iifl_groww.png",
    },
    {
      name: "Shriram Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/shriram-multicap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "Axis Regular Saver Fund",
      link: "https://groww.in/mutual-funds/axis-i-come-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Samco Overnight Fund",
      link: "https://groww.in/mutual-funds/samco-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/samco_groww.png",
    },
    {
      name: "Edelweiss Emerging Markets Opportunities Equity Offshore Fund",
      link: "https://groww.in/mutual-funds/edelweiss-emerging-markets-opportunities-equity-offshore-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Equity Savings Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "HSBC Global Emerging Markets Fund",
      link: "https://groww.in/mutual-funds/hsbc-emerging-markets-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Axis Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/axis-dynamic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Aditya Birla Sun Life ESG Integration Strategy Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-esg-integration-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Quant Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/quant-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/escorts_groww.png",
    },
    {
      name: "Kotak Nifty SDL Plus AAA PSU Bond Jul 2028 60:40 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-plus-aaa-psu-bond-jul-2028-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "IDBI Liquid Fund",
      link: "https://groww.in/mutual-funds/idbi-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "ITI Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/iti-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Bank of India Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/boi-axa-regular-return-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "PGIM India Emerging Markets Equity Fund",
      link: "https://groww.in/mutual-funds/pgim-india-emerging-markets-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "PGIM India Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/pgim-india-hybrid-equity-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Bank of India Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/boi-axa-equity-debt-rebalancer-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "SBI Retirement Benefit Fund",
      link: "https://groww.in/mutual-funds/sbi-retirement-benefit-fund-conservative-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Baroda BNP Paribas Business Cycle Fund",
      link: "https://groww.in/mutual-funds/baroda-business-cycle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Motilal Oswal Balance Advantage Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-focused-dynamic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "Kotak Medium Term Fund",
      link: "https://groww.in/mutual-funds/kotak-medium-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Nippon India Nifty G-Sec Oct 2028 Maturity Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-g-sec-oct-2028-maturity-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "UTI Money Market Fund",
      link: "https://groww.in/mutual-funds/uti-money-market-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "HDFC Arbitrage Fund",
      link: "https://groww.in/mutual-funds/hdfc-arbitrage-fund-wp-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Bank of India Tax Advantage Fund",
      link: "https://groww.in/mutual-funds/boi-axa-tax-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Axis Treasury Advantage Direct Fund",
      link: "https://groww.in/mutual-funds/axis-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "WhiteOak Capital Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Motilal Oswal 5 Year G-Sec FoF Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-5-year-g-sec-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "HDFC NIFTY G-Sec Apr 2029 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-apr-2029-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "WhiteOak Capital Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Edelweiss Europe Dynamic Equity Offshore Fund",
      link: "https://groww.in/mutual-funds/edelweiss-europe-dynamic-equity-offshore-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Axis Strategic Bond Fund",
      link: "https://groww.in/mutual-funds/axis-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential Debt Management Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-dynamic-accrual-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Kotak Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/kotak-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "LIC MF Midcap Fund",
      link: "https://groww.in/mutual-funds/lic-mf-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Baroda BNP Paribas Liquid Direct Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-liquid-fund-plan-b-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "IDBI Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/idbi-diversified-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Nippon India Nifty G-Sec Jun 2036 Maturity Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-g-sec-jun-2036-maturity-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Motilal Oswal Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-most-ultra-short-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "LIC MF Medium to Long Duration Bond Fund",
      link: "https://groww.in/mutual-funds/lic-mf-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Nippon India Equity Savings Fund",
      link: "https://groww.in/mutual-funds/nippon-india-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Axis Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/axis-equity-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Edelweiss Focused Fund",
      link: "https://groww.in/mutual-funds/edelweiss-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Union Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/union-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "ICICI Prudential Exports and Services Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-exports-and-other-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HDFC Nifty G-sec Dec 2026 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-dec-2026-index-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "DSP Tax Saver Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HDFC NIFTY SDL Plus G-Sec Jun 2027 40:60 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-sdl-plus-g-sec-jun-2027-40:60-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "BHARAT Bond ETF FOF - April 2033 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-etf-fof-april-2033-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Tata Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/tata-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "Mirae Asset Money Market Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Edelweiss Nifty 50 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "PGIM India Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/pgim-india-dynamic-bond-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "UTI Nifty SDL Plus AAA PSU Bond Apr 2026 75:25 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-sdl-plus-aaa-psu-bond-apr-2026-75:25-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "LIC MF Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/lic-mf-i-come-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Baroda BNP Paribas Aqua FoF Fund",
      link: "https://groww.in/mutual-funds/bnp-paribas-funds-aqua-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "NJ Overnight Fund",
      link: "https://groww.in/mutual-funds/nj-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/nj_groww.png",
    },
    {
      name: "Bandhan Arbitrage Fund",
      link: "https://groww.in/mutual-funds/idfc-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "PGIM India Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/pgim-india-ultra-short-duration-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Canara Robeco Equity Tax Saver Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-equity-taxsaver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Mahindra Manulife Consumption Fund",
      link: "https://groww.in/mutual-funds/mahindra-rural-bharat-and-consumption-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Quantum Equity Fund",
      link: "https://groww.in/mutual-funds/quantum-equity-fund-of-funds-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Shriram Long Term Equity Fund",
      link: "https://groww.in/mutual-funds/shriram-long-term-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "Quantum Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/quantum-dynamic-bond-fund-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Invesco India - Invesco Pan European Equity FoF Fund",
      link: "https://groww.in/mutual-funds/invesco-india-pan-european-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Navi ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/navi-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "PGIM India Gilt Fund",
      link: "https://groww.in/mutual-funds/pgim-india-gilt-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "UTI Long Duration Fund",
      link: "https://groww.in/mutual-funds/uti-long-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "IDBI Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/idbi-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "IDBI Healthcare Fund",
      link: "https://groww.in/mutual-funds/idbi-healthcare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "JM Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/jm-balanced-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Edelweiss ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/edelweiss-elss-tax-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "SBI CRISIL IBX Gilt Index - April 2029 Fund",
      link: "https://groww.in/mutual-funds/sbi-crisil-ibx-gilt-index-april-2029-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "NJ Arbitrage Fund",
      link: "https://groww.in/mutual-funds/nj-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/nj_groww.png",
    },
    {
      name: "UTI Banking and Financial Services Fund",
      link: "https://groww.in/mutual-funds/uti-banking-sector-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX Gilt-April 2026 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-gilt-april-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "PGIM India Liquid Fund",
      link: "https://groww.in/mutual-funds/pgim-india-liquid-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "JM Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/jm-floater-long-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Franklin India Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/franklin-india-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Sundaram Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/sundaram-flexible-fund-short-term-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Taurus Large Cap Fund",
      link: "https://groww.in/mutual-funds/taurus-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Overnight Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HSBC Mid Cap Fund",
      link: "https://groww.in/mutual-funds/hsbc-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Kotak Bond Short Term Fund",
      link: "https://groww.in/mutual-funds/kotak-bond-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "ICICI Prudential Bond Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-i-come-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "HSBC Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/hsbc-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "ITI Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/iti-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Equity Savings Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Navi 3 in 1 Fund",
      link: "https://groww.in/mutual-funds/navi-3-in-1-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Bandhan Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/idfc-dynamic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "DSP Regular Savings Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-mip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Kotak ESG Exclusionary Strategy Fund",
      link: "https://groww.in/mutual-funds/kotak-esg-exclusionary-strategy-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Navi Large Cap Equity Fund",
      link: "https://groww.in/mutual-funds/navi-large-cap-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Tata Income Fund",
      link: "https://groww.in/mutual-funds/tata-long-term-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "JM Focused Fund",
      link: "https://groww.in/mutual-funds/jm-core-11-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Sundaram Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/sundaram-flexible-fund-flexible-i-come-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "UTI Focussed Equity Fund",
      link: "https://groww.in/mutual-funds/uti-focussed-equity-fund-series-vi-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX 60:40 SDL+AAA PSU-Apr 2027 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-sdl-plus-aaa-psu-apr-2027-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Taurus Infrastructure Fund",
      link: "https://groww.in/mutual-funds/taurus-infrastructure-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Mirae Asset Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "LIC MF Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/lic-mf-balanced-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Union Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/union-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Mahindra Manulife Equity Savings Fund",
      link: "https://groww.in/mutual-funds/mahindra-dhan-sanchay-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Nippon India Nifty SDL Plus G-Sec - Jun 2029 Maturity 70:30 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-sdl-plus-g-sec-jun-2029-maturity-70:30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Bandhan Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Bandhan Regular Savings Fund",
      link: "https://groww.in/mutual-funds/idfc-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Axis Money Market Fund",
      link: "https://groww.in/mutual-funds/axis-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "IDBI Nifty Next 50 Index Fund",
      link: "https://groww.in/mutual-funds/idbi-nifty-junior-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Motilal Oswal Liquid Fund",
      link: "https://groww.in/mutual-funds/motilal-oswal-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/motilal_groww.png",
    },
    {
      name: "SBI CRISIL IBX SDL Index - September 2027 Fund",
      link: "https://groww.in/mutual-funds/sbi-crisil-ibx-sdl-index-september-2027-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Taurus Mid Cap Fund",
      link: "https://groww.in/mutual-funds/taurus-mid-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Kotak All Weather Debt FOF Fund",
      link: "https://groww.in/mutual-funds/kotak-all-weather-debt-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "UTI India Consumer Fund",
      link: "https://groww.in/mutual-funds/uti-india-lifestyle-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bandhan Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/idfc-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Union Largecap Fund",
      link: "https://groww.in/mutual-funds/union-focussed-largecap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX 60:40 SDL+ AAA PSU Apr 2026 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-60:40-sdl-+-aaa-psu-apr-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bandhan Liquid Fund",
      link: "https://groww.in/mutual-funds/idfc-cash-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "DSP Focus Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-focus-25-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HSBC Managed Solutions India Growth Fund",
      link: "https://groww.in/mutual-funds/hsbc-managed-solutions-india-growth-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "HSBC Business Cycles Fund",
      link: "https://groww.in/mutual-funds/hsbc-business-cycles-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Nippon IndiaRetirement Fund",
      link: "https://groww.in/mutual-funds/nippon-indiaretirement-fund-i-come-generation-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Tata Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/tata-retirement-savings-fund-conservative-plan-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/tata_groww.png",
    },
    {
      name: "IDBI Short Term Bond Fund",
      link: "https://groww.in/mutual-funds/idbi-short-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Taurus Short Term Income Fund",
      link: "https://groww.in/mutual-funds/taurus-short-term-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Invesco India Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/invesco-india-dynamic-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI CRISIL SDL Maturity June 2027 Index Fund",
      link: "https://groww.in/mutual-funds/uti-crisil-sdl-maturity-june-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bank of India Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/boi-axa-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Union Value Discovery Fund",
      link: "https://groww.in/mutual-funds/union-value-discovery-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "DSP Overnight Fund",
      link: "https://groww.in/mutual-funds/dsp-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "DSP Nifty SDL Plus G-Sec Sep 2027 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-sdl-plus-g-sec-sep-2027-50:50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Quantum Tax Saving Fund",
      link: "https://groww.in/mutual-funds/quantum-tax-saving-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "LIC MF Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/lic-mf-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "UTI S&P BSE Housing Index Fund",
      link: "https://groww.in/mutual-funds/uti-s-p-bse-housing-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Edelweiss NIFTY PSU Bond Plus SDL Apr 2027 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-psu-bond-plus-sdl-index-fund-2027-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Baroda BNP Paribas Floater Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-floater-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Axis Nifty SDL September 2026 Debt Index Fund",
      link: "https://groww.in/mutual-funds/axis-nifty-sdl-september-2026-debt-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Sundaram Medium Term Bond Fund",
      link: "https://groww.in/mutual-funds/sundaram-bond-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Axis Equity Saver Fund",
      link: "https://groww.in/mutual-funds/axis-equity-saver-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Taurus ELSS Tax Saver Fund",
      link: "https://groww.in/mutual-funds/taurus-elss-tax-saver-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "IDBI Midcap Fund",
      link: "https://groww.in/mutual-funds/idbi-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Nippon India Hybrid Bond Fund",
      link: "https://groww.in/mutual-funds/nippon-india-hybrid-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX SDL Jun 2032 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-sdl-jun-2032-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Edelweiss ASEAN Equity Off Shore Fund",
      link: "https://groww.in/mutual-funds/edelweiss-asean-equity-offshore-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Nippon India Floating Rate Fund",
      link: "https://groww.in/mutual-funds/nippon-india-floating-rate-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "HSBC Global Equity Climate Change FoF Fund",
      link: "https://groww.in/mutual-funds/hsbc-global-equity-climate-change-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Axis All Seasons Debt FoF Fund",
      link: "https://groww.in/mutual-funds/axis-all-seasons-debt-fund-of-funds-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "HDFC NIFTY G-Sec Jun 2036 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-jun-2036-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Franklin India Life Stage FoF The 50s Plus Floating Rate Fund",
      link: "https://groww.in/mutual-funds/franklin-india-life-stage-50s-plus-floating-rate-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "DSP Strategic Bond Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-strategic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Taurus Flexi Cap Fund",
      link: "https://groww.in/mutual-funds/taurus-starshare-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Invesco India Gold Fund",
      link: "https://groww.in/mutual-funds/invesco-india-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Franklin India Equity Advantage Fund",
      link: "https://groww.in/mutual-funds/franklin-india-flexi-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Bandhan All Seasons Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-all-seasons-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Invesco India Liquid Fund",
      link: "https://groww.in/mutual-funds/invesco-india-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "BHARAT Bond ETF FOF - April 2032 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-etf-fof-april-2032-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Edelweiss Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/edelweiss-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Kotak Nifty SDL Apr 2027 Top 12 Equal Weight Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-apr-2027-top-12-equal-weight-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Axis Credit Risk Fund",
      link: "https://groww.in/mutual-funds/axis-fixed-i-come-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Invesco India Credit Risk Fund",
      link: "https://groww.in/mutual-funds/invesco-india-corporate-bond-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Asset Allocator FoF Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-asset-allocator-multi-manager-fof-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Sundaram Liquid Fund",
      link: "https://groww.in/mutual-funds/sundaram-liquid-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Nippon India Nifty G-Sec Sep 2027 Maturity Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-g-sec-sep-2027-maturity-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "Kotak Gilt Investment PF & Trust Fund",
      link: "https://groww.in/mutual-funds/kotak-gilt-investment-pf-trust-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Bandhan Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-super-saver-i-come-fund-short-term-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Kotak Bond Fund",
      link: "https://groww.in/mutual-funds/kotak-bond-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "UTI Overnight Fund",
      link: "https://groww.in/mutual-funds/uti-g-sec-short-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "HDFC Nifty SDL Oct 2026 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-sdl-oct-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "BHARAT Bond FOF - April 2023 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-fof-april-2023-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "HSBC Managed Solutions India Moderate Fund",
      link: "https://groww.in/mutual-funds/hsbc-managed-solutions-india-moderate-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Mahindra Manulife ELSS Fund",
      link: "https://groww.in/mutual-funds/mahindra-kar-bachat-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "HSBC Liquid Fund",
      link: "https://groww.in/mutual-funds/hsbc-cash-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "LIC MF Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/lic-mf-monthly-i-come-plan-direct-cumulative",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Nippon India Nifty SDL Plus G-Sec - Jun 2028 Maturity 70:30 Index Fund",
      link: "https://groww.in/mutual-funds/nippon-india-nifty-sdl-plus-g-sec-jun-2028-maturity-70:30-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "ICICI Prudential Global Stable Equity Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-global-stable-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Franklin India Corporate Debt Fund",
      link: "https://groww.in/mutual-funds/franklin-india-iba-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Principal Global Opportunities Fund",
      link: "https://groww.in/mutual-funds/principal-global-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/principal_groww.png",
    },
    {
      name: "Kotak Money Market Fund",
      link: "https://groww.in/mutual-funds/kotak-floater-short-term-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Mirae Asset Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-prudence-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Bandhan Money Manager Fund",
      link: "https://groww.in/mutual-funds/idfc-money-manager-treasury-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Reliance Focused Large Cap Fund",
      link: "https://groww.in/mutual-funds/reliance-focused-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "UTI Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/uti-mis-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bandhan Focused Equity Fund",
      link: "https://groww.in/mutual-funds/idfc-imperial-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Franklin India Debt Hybrid Fund",
      link: "https://groww.in/mutual-funds/franklin-india-mip-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "UTI Nifty SDL Plus AAA PSU Bond Apr 2028 75:25 Index Fund",
      link: "https://groww.in/mutual-funds/uti-nifty-sdl-plus-aaa-psu-bond-apr-2028-75:25-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Franklin India Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/franklin-india-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "WhiteOak Capital Liquid Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Sundaram Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/sundaram-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "ICICI Prudential Global Advantage Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-global-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "PGIM India Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/pgim-india-corporate-bond-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "SBI Capital Protection Oriented Fund",
      link: "https://groww.in/mutual-funds/sbi-capital-protection-oriented-fund-series-a-plan-8-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Axis Dynamic Bond Direct Fund",
      link: "https://groww.in/mutual-funds/axis-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "SBI Fixed Maturity Plan - Series 58 (1842 Days) Fund",
      link: "https://groww.in/mutual-funds/sbi-fixed-maturity-plan-series-58-(1842-days)-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sbi_groww.png",
    },
    {
      name: "Mirae Asset Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "HSBC Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/hsbc-equity-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "IDBI Long Term Value Fund",
      link: "https://groww.in/mutual-funds/idbi-long-term-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "ICICI Prudential Retirement Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-retirement-fund-pure-debt-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Quantum India ESG Equity Fund",
      link: "https://groww.in/mutual-funds/quantum-india-esg-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/quantum_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Commodity Equities Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-commodity-equities-fund-ga-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Principal Large Cap Fund",
      link: "https://groww.in/mutual-funds/principal-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/principal_groww.png",
    },
    {
      name: "Navi Regular Savings Fund",
      link: "https://groww.in/mutual-funds/navi-regular-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "HDFC Nifty G-Sec July 2031 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-july-2031-index-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "Franklin India Floating Rate Fund",
      link: "https://groww.in/mutual-funds/franklin-india-cash-management-account-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Mirae Asset Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "DSP Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "UTI Gilt Fund",
      link: "https://groww.in/mutual-funds/uti-gilt-advantage-fund-long-term-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bank of India Arbitrage Fund",
      link: "https://groww.in/mutual-funds/boi-axa-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Baroda Large Cap Direct Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-large-cap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Mirae Asset Banking and PSU Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-banking-and-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "JM Money Market Fund",
      link: "https://groww.in/mutual-funds/jm-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Axis Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/axis-retirement-savings-fund-dynamic-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Kotak Floating Rate Fund",
      link: "https://groww.in/mutual-funds/kotak-floating-rate-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX AAA - Jun 2023 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-aaa-jun-2023-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Kotak Overnight Fund",
      link: "https://groww.in/mutual-funds/kotak-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Navi Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/navi-equity-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Sundaram Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/sundaram-conservative-hybrid-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Bandhan Low Duration Fund",
      link: "https://groww.in/mutual-funds/idfc-low-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Canara Robeco Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "JM Arbitrage Fund",
      link: "https://groww.in/mutual-funds/jm-arbitrage-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "DSP Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/dsp-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "LIC MF Focused 30 Equity Fund",
      link: "https://groww.in/mutual-funds/lic-mf-focused-30-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX 50:50 Gilt Plus SDL Apr 2028 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-50:50-gilt-plus-sdl-apr-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bandhan CRISIL IBX 90:10 SDL Plus Gilt-September 2027 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-crisil-ibx-90:10-sdl-plus-gilt-september-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Baroda BNP Paribas Dynamic Bond Plan Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-dynamic-bond-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Sundaram Money Market Fund",
      link: "https://groww.in/mutual-funds/sundaram-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Franklin India Money Market Fund",
      link: "https://groww.in/mutual-funds/franklin-india-savings-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Axis Gilt Fund",
      link: "https://groww.in/mutual-funds/axis-constant-maturity-10-year-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Invesco India Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/invesco-india-aggressive-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "HDFC Nifty G-Sec Jun 2027 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-jun-2027-index-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "HDFC Nifty G-Sec Sep 2032 Index Fund",
      link: "https://groww.in/mutual-funds/hdfc-nifty-g-sec-sep-2032-v1-index-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hdfc_groww.png",
    },
    {
      name: "JM Short Duration Fund",
      link: "https://groww.in/mutual-funds/jm-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Mahindra Manulife Low Duration Fund",
      link: "https://groww.in/mutual-funds/mahindra-alp-samay-bachat-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Union Equity Savings Fund",
      link: "https://groww.in/mutual-funds/union-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Union Value Fund",
      link: "https://groww.in/mutual-funds/union-value-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Baroda BNP Paribas Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-conservative-hybrid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "UTI Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/uti-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Bandhan Asset Allocation Moderate Fund",
      link: "https://groww.in/mutual-funds/idfc-asset-allocation-fof-moderate-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Invesco India ESG Equity Fund",
      link: "https://groww.in/mutual-funds/invesco-india-esg-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Kotak Global Emerging Market Fund",
      link: "https://groww.in/mutual-funds/kotak-global-emerging-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Principal Midcap Fund",
      link: "https://groww.in/mutual-funds/principal-midcap-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/principal_groww.png",
    },
    {
      name: "Invesco India Banking and PSU Fund",
      link: "https://groww.in/mutual-funds/invesco-india-banking-and-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Sundaram Banking & PSU Fund",
      link: "https://groww.in/mutual-funds/sundaram-banking-psu-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "LIC MF Short Duration Fund",
      link: "https://groww.in/mutual-funds/lic-mf-short-term-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Retirement Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-retirement-fund-the-40s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Sundaram Equity Hybrid Fund",
      link: "https://groww.in/mutual-funds/sundaram-balanced-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Axis CRISIL IBX 50:50 Gilt Plus SDL Jun 2028 Index Fund",
      link: "https://groww.in/mutual-funds/axis-crisil-ibx-5050-gilt-plus-sdl-jun-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Axis ESG Equity Fund",
      link: "https://groww.in/mutual-funds/axis-esg-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Aditya Birla Sun Life MNC Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-mnc-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Bandhan CRISIL IBX 90:10 SDL Plus Gilt- November 2026 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-crisil-ibx-90:10-sdl-plus-gilt-november-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Shriram Aggressive Hybrid Fund",
      link: "https://groww.in/mutual-funds/shriram-equity-and-debt-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "Edelweiss Long Term Equity Fund",
      link: "https://groww.in/mutual-funds/edelweiss-elss-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Kotak ESG Opportunities Fund",
      link: "https://groww.in/mutual-funds/kotak-esg-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Navi Liquid Fund",
      link: "https://groww.in/mutual-funds/navi-liquid-fund-super-institutional-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Franklin India Multi Asset Solution Fund",
      link: "https://groww.in/mutual-funds/franklin-india-multi-asset-solution-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Union Focused Fund",
      link: "https://groww.in/mutual-funds/union-focused-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Bandhan CRISIL IBX 90:10 SDL Plus Gilt- April 2032 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-crisil-ibx-90:10-sdl-plus-gilt-april-2032-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "ITI Arbitrage Fund",
      link: "https://groww.in/mutual-funds/iti-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Aditya Birla Sun Life International Equity Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-international-equity-fund-plan-b-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Union Tax Saver (ELSS) Fund",
      link: "https://groww.in/mutual-funds/union-tax-saver-scheme-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Invesco India Money Market Fund",
      link: "https://groww.in/mutual-funds/invesco-india-credit-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "LIC MF Arbitrage Fund",
      link: "https://groww.in/mutual-funds/lic-mf-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Edelweiss NIFTY PSU Bond Plus SDL Apr 2026 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-nifty-psu-bond-plus-sdl-index-fund-2026-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "ICICI Prudential Retirement Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-retirement-fund-hybrid-conservative-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "DSP CRISIL SDL Plus G-Sec Apr 2033 50:50 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-crisil-sdl-plus-g-sec-apr-2033-50:50-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "UTI Value Fund",
      link: "https://groww.in/mutual-funds/uti-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "BNP Paribas Multi Cap Fund",
      link: "https://groww.in/mutual-funds/bnp-paribas-dividend-yield-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bnp_groww.png",
    },
    {
      name: "HSBC Infrastructure Equity Fund",
      link: "https://groww.in/mutual-funds/hsbc-infrastructure-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Sundaram Equity Fund",
      link: "https://groww.in/mutual-funds/sundaram-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "DSP Global Allocation FoF Fund",
      link: "https://groww.in/mutual-funds/dsp-global-allocation-fof-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Bandhan Asset Allocation Conservative Fund",
      link: "https://groww.in/mutual-funds/idfc-asset-allocation-fof-conservative-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Shriram Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/shriram-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "UTI Focussed Equity Fund",
      link: "https://groww.in/mutual-funds/uti-focussed-equity-fund-series-i-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Baroda BNP Paribas Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Bandhan Asset Allocation Aggressive Fund",
      link: "https://groww.in/mutual-funds/idfc-asset-allocation-fof-aggressive-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty SDL Sep 2027 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-sdl-sep-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Taurus Tax Shield Fund",
      link: "https://groww.in/mutual-funds/taurus-taxshield-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Sundaram Diversified Equity Fund",
      link: "https://groww.in/mutual-funds/sundaram-taxsaver-open-ended-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Bandhan Credit Risk Fund",
      link: "https://groww.in/mutual-funds/idfc-credit-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Kotak Savings Fund",
      link: "https://groww.in/mutual-funds/kotak-treasury-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty SDL Sep 2025 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-sdl-sep-2025-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX Gilt Apr 2028 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-gilt-apr-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "ICICI Prudential ESG Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-esg-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Sundaram Tax Savings Fund",
      link: "https://groww.in/mutual-funds/sundaram-tax-savings-fund-direct",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "JM Liquid Fund",
      link: "https://groww.in/mutual-funds/jm-high-liquidity-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Franklin India Equity Savings Fund",
      link: "https://groww.in/mutual-funds/franklin-india-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Mahindra Manulife Arbitrage Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-arbitrage-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "UTI Floater Fund",
      link: "https://groww.in/mutual-funds/uti-floater-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "ITI Liquid Fund",
      link: "https://groww.in/mutual-funds/iti-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Union Money Market Fund",
      link: "https://groww.in/mutual-funds/union-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Kotak Nifty SDL Jul 2033 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-jul-2033-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "UTI Fixed Term Income Fund",
      link: "https://groww.in/mutual-funds/uti-fixed-term-i-come-fund-series-xxx-plan-2-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Edelweiss CRISIL IBX 50:50 Gilt Plus SDL Short Duration Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-crisil-ibx-50:50-gilt-plus-sdl-short-duration-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Sundaram Short Term Debt Fund",
      link: "https://groww.in/mutual-funds/sundaram-select-debt-short-term-asset-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Taurus Banking & Financial Services Fund",
      link: "https://groww.in/mutual-funds/taurus-banking-financial-services-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "ICICI Prudential Nifty G-Sec Dec 2030 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-g-sec-dec-2030-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Aditya Birla Sun Life ESG Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-esg-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Baroda BNP Paribas Money Market Fund",
      link: "https://groww.in/mutual-funds/baroda-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Retirement Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-retirement-fund-the-50s-plus-debt-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Edelweiss CRISIL IBX 50:50 Gilt Plus SDL April 2037 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-crisil-ibx-50:50-gilt-plus-sdl-april-2037-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Franklin India Liquid Fund",
      link: "https://groww.in/mutual-funds/franklin-india-tma-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "WhiteOak Capital Ultra Duration Term Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-ultra-duration-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Edelweiss Money Market Fund",
      link: "https://groww.in/mutual-funds/edelweiss-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "JM Medium to Long Duration Fund",
      link: "https://groww.in/mutual-funds/jm-i-come-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Baroda BNP Paribas Equity Savings Fund",
      link: "https://groww.in/mutual-funds/baroda-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Sundaram Overnight Fund",
      link: "https://groww.in/mutual-funds/sundaram-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "JM Low Duration Fund",
      link: "https://groww.in/mutual-funds/jm-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Baroda BNP Paribas Nifty SDL December 2026 Index Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-nifty-sdl-december-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Gold Direct Fund",
      link: "https://groww.in/mutual-funds/birla-sun-life-gold-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Invesco India Focused 20 Equity Fund",
      link: "https://groww.in/mutual-funds/invesco-india-focused-20-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "BHARAT Bond FOF - April 2031 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-fof-april-2031-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "PGIM India CRISIL IBX Gilt Index - Apr 2028 Fund",
      link: "https://groww.in/mutual-funds/pgim-india-crisil-ibx-gilt-index-apr-2028-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Kotak Credit Risk Fund",
      link: "https://groww.in/mutual-funds/kotak-i-come-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "DSP 10Y G-Sec Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-constant-maturity-10y-g-sec-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Bandhan Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/idfc-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Axis Floater Fund",
      link: "https://groww.in/mutual-funds/axis-floater-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "ICICI Prudential Nifty SDL Sep 2027 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-sdl-sep-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Shriram Overnight Fund",
      link: "https://groww.in/mutual-funds/shriram-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/shriram_groww.png",
    },
    {
      name: "UTI Fixed Term Income Fund",
      link: "https://groww.in/mutual-funds/uti-fixed-term-i-come-fund-series-xxiii-plan-15-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Mahindra Manulife Short Duration Fund",
      link: "https://groww.in/mutual-funds/mahindra-manulife-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Nifty SDL Apr 2027 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-nifty-sdl-apr-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Mirae Asset Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Baroda BNP Paribas Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "HSBC Tax Saver Equity Fund",
      link: "https://groww.in/mutual-funds/hsbc-tax-saver-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "WhiteOak Capital Overnight Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Edelweiss Focused Equity Fund",
      link: "https://groww.in/mutual-funds/edelweiss-focused-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Edelweiss Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/edelweiss-corporate-debt-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "ITI Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/iti-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Franklin India Overnight Fund",
      link: "https://groww.in/mutual-funds/franklin-india-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Union Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/union-corporate-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Aditya Birla Sun Life Retirement Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-retirement-fund-the-50s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "HSBC Low Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "LIC MF ELSS Fund",
      link: "https://groww.in/mutual-funds/lic-mf-tax-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "BHARAT Bond FOF - April 2030 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-fof-april-2030-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Baroda BNP Paribas Overnight Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Sundaram Low Duration Fund",
      link: "https://groww.in/mutual-funds/sundaram-ultra-short-term-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Kotak US Equity Fund",
      link: "https://groww.in/mutual-funds/kotak-us-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Nippon India Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/nippon-india-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "BHARAT Bond FOF - April 2025 Fund",
      link: "https://groww.in/mutual-funds/bharat-bond-fof-april-2025-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "ICICI Prudential Nifty SDL Sep 2026 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-sdl-sep-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "Mirae Asset Short Duration Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Union Overnight Fund",
      link: "https://groww.in/mutual-funds/union-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Navi Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/navi-ultra-short-term-fund-super-institutional-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/peerless_groww.png",
    },
    {
      name: "Axis Fixed Term Plan Series 109 (111 Days) Fund",
      link: "https://groww.in/mutual-funds/axis-fixed-term-plan-series-109-(111-days)-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Franklin India Liquid Fund",
      link: "https://groww.in/mutual-funds/franklin-india-liquid-fund-super-institutional-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "LIC MF Overnight Fund",
      link: "https://groww.in/mutual-funds/lic-mf-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "Mirae Asset Cash Management Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-cash-management-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "UTI Fixed Term Income Fund",
      link: "https://groww.in/mutual-funds/uti-fixed-term-i-come-fund-series-xxix-plan-8-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "WhiteOak Capital Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/whiteoak-capital-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/whiteoak_groww.png",
    },
    {
      name: "Sundaram Smart NIFTY 100 Equal Weight Fund",
      link: "https://groww.in/mutual-funds/sundaram-smart-nifty-100-equal-weight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "PGIM India Balanced Advantage Fund",
      link: "https://groww.in/mutual-funds/pgim-india-balanced-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "UTI CRISIL SDL Maturity April 2033 Index Fund",
      link: "https://groww.in/mutual-funds/uti-crisil-sdl-maturity-april-2033-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Baroda Conservative Hybrid Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-mip-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Franklin India Life Stage FoF The 20s Plan Fund",
      link: "https://groww.in/mutual-funds/franklin-india-life-stage-20s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Taurus Largecap Equity Fund",
      link: "https://groww.in/mutual-funds/taurus-bonanza-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Baroda Equity Linked Saving Scheme 96 Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-elss-96-plan-b-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Nippon India Gilt Securities Fund",
      link: "https://groww.in/mutual-funds/nippon-india-gilt-securities-fund-direct-defined-maturity-date-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/reliance_groww.png",
    },
    {
      name: "DSP Floater Fund",
      link: "https://groww.in/mutual-funds/dsp-floater-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Bandhan Overnight Fund",
      link: "https://groww.in/mutual-funds/idfc-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Aditya Birla Sun Life CRISIL IBX Gilt -Apr 2029 Index Fund",
      link: "https://groww.in/mutual-funds/aditya-birla-sun-life-crisil-ibx-gilt-apr-2029-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/birla_groww.png",
    },
    {
      name: "Edelweiss CRISIL PSU Plus SDL 50:50 Oct 2025 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-crisil-psu-plus-sdl-50:50-oct-2025-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "LIC MF Equity Savings Fund",
      link: "https://groww.in/mutual-funds/lic-mf-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "ITI Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/iti-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "Mirae Asset Nifty SDL June 2028 Index Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nifty-sdl-june-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "IDBI Focused 30 Equity Fund",
      link: "https://groww.in/mutual-funds/idbi-focused-30-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "IDBI Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/idbi-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "DSP Ultra Short Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-money-manager-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HSBC Overnight Fund",
      link: "https://groww.in/mutual-funds/hsbc-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Mirae Asset Nifty SDL Jun 2027 Index Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-nifty-sdl-jun-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "IDBI Equity Advantage Fund",
      link: "https://groww.in/mutual-funds/idbi-equity-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Canara Robeco Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-medium-term-opportunities-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Axis Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/axis-retirement-savings-fund-conservative-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "DSP Credit Risk Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-i-come-opportunities-fund-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Invesco India Tax Plan Fund",
      link: "https://groww.in/mutual-funds/invesco-india-tax-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Baroda BNP Paribas ELSS Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-elss-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Baroda Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-balance-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Bandhan Crisil IBX Gilt April 2032 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-crisil-ibx-gilt-april-2032-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "HSBC Medium Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-medium-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Franklin India Life Stage FoF The 30s Plan Fund",
      link: "https://groww.in/mutual-funds/franklin-india-life-stage-30s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Franklin India Life Stage FoF The 40s Plan Fund",
      link: "https://groww.in/mutual-funds/franklin-india-life-stage-40s-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Invesco India Equity Savings Fund",
      link: "https://groww.in/mutual-funds/invesco-india-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "UTI Gilt Fund",
      link: "https://groww.in/mutual-funds/uti-gilt-fund-with-10-year-constant-duration-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "TRUSTMF Short Term Fund",
      link: "https://groww.in/mutual-funds/trust-mf-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "LIC MF Gilt Fund",
      link: "https://groww.in/mutual-funds/lic-mf-g-sec-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/lic_groww.png",
    },
    {
      name: "DSP Short Term Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Mirae Asset CRISIL IBX Gilt Index - April 2033 Index Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-crisil-ibx-gilt-index-april-2033-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "ICICI Prudential Nifty SDL Dec 2028 Index Fund",
      link: "https://groww.in/mutual-funds/icici-prudential-nifty-sdl-dec-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/icici_groww.png",
    },
    {
      name: "IDBI Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/idbi-prudence-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Principal Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/principal-asset-allocation-fund-of-funds-aggressive-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Kotak Nifty SDL Plus AAA PSU Bond Jul 2033 60:40 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-plus-aaa-psu-bond-jul-2033-60:40-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "Canara Robeco Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Edelweiss CRISIL IBX 50:50 Gilt Plus SDL Sep 2028 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-crisil-ibx-50:50-gilt-plus-sdl-sep-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Low Duration Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Canara Robeco Overnight Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Bandhan CRISIL IBX Gilt June 2027 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-gilt-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "PGIM India Money Market Fund",
      link: "https://groww.in/mutual-funds/pgim-india-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Mahindra Manulife Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/mahindra-credit-risk-yojana-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "DSP Low Duration Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Union Hybrid Equity Fund",
      link: "https://groww.in/mutual-funds/union-hybrid-equity-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "HSBC Managed Solutions India Conservative Fund",
      link: "https://groww.in/mutual-funds/hsbc-managed-solutions-india-conservative-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Invesco India Low Duration Fund",
      link: "https://groww.in/mutual-funds/invesco-india-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Bandhan CRISIL IBX Gilt April 2028 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-gilt-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Mahindra Manulife Overnight Fund",
      link: "https://groww.in/mutual-funds/mahindra-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mahindra_groww.png",
    },
    {
      name: "Kotak Nifty SDL Jul 2026 Index Fund",
      link: "https://groww.in/mutual-funds/kotak-nifty-sdl-jul-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/kotak_groww.png",
    },
    {
      name: "HSBC Credit Risk Fund",
      link: "https://groww.in/mutual-funds/hsbc-credit-risk-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "DSP Global Allocation Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-global-allocation-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "JM Overnight Fund",
      link: "https://groww.in/mutual-funds/jm-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "Union Arbitrage Fund",
      link: "https://groww.in/mutual-funds/union-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "DSP Nifty SDL Plus G-Sec Jun 2028 30:70 Index Fund",
      link: "https://groww.in/mutual-funds/dsp-nifty-sdl-plus-g-sec-jun-2028-30:70-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "HSBC Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/hsbc-corporate-bond-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Baroda BNP Paribas NIFTY SDL December 2028 Index Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-nifty-sdl-december-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Bandhan Equity Savings Fund",
      link: "https://groww.in/mutual-funds/idfc-arbitrage-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "DSP Savings Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-treasury-bill-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Invesco India Gilt Fund",
      link: "https://groww.in/mutual-funds/invesco-india-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "HSBC Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Invesco India Overnight Fund",
      link: "https://groww.in/mutual-funds/invesco-india-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Axis CRISIL IBX SDL May 2027 Index Fund",
      link: "https://groww.in/mutual-funds/axis-crisil-sdl-2027-debt-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "Invesco India Treasury Advantage Fund",
      link: "https://groww.in/mutual-funds/invesco-india-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Mirae Asset Banking and PSU Debt Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-banking-and-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "Invesco India Equity & Bond Fund",
      link: "https://groww.in/mutual-funds/invesco-india-equity-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Canara Robeco Savings Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-savings-plus-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Franklin India Life Stage FoF The 50s Plus Fund",
      link: "https://groww.in/mutual-funds/franklin-india-life-stage-50s-plus-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/franklin_groww.png",
    },
    {
      name: "Invesco India Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/invesco-india-ultra-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Canara Robeco Gilt Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-gilt-pgs-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "HSBC CRISIL IBX Gilt June 2027 Index Fund",
      link: "https://groww.in/mutual-funds/hsbc-crisil-ibx-gilt-june-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Principal Retirement Savings Fund",
      link: "https://groww.in/mutual-funds/principal-asset-allocation-fund-of-funds-conservative-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Taurus Liquid Fund",
      link: "https://groww.in/mutual-funds/taurus-liquid-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "UTI Medium Duration Fund",
      link: "https://groww.in/mutual-funds/uti-medium-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "Union Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/union-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "PGIM India Low Duration Fund",
      link: "https://groww.in/mutual-funds/pgim-india-low-duration-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "HSBC Medium to Long Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-i-come-fund-invtt-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Baroda BNP Paribas Gilt Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "HSBC Flexi Debt Fund",
      link: "https://groww.in/mutual-funds/hsbc-flexi-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "ITI Overnight Fund",
      link: "https://groww.in/mutual-funds/iti-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/iti_groww.png",
    },
    {
      name: "DSP Bond Fund",
      link: "https://groww.in/mutual-funds/dsp-blackrock-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dsp_groww.png",
    },
    {
      name: "Canara Robeco Short Duration Fund",
      link: "https://groww.in/mutual-funds/canara-robeco-yield-advantage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/canara_groww.png",
    },
    {
      name: "Bandhan Floating Rate Fund",
      link: "https://groww.in/mutual-funds/idfc-floating-rate-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "Invesco India Medium Duration Fund",
      link: "https://groww.in/mutual-funds/invesco-india-medium-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Union Gilt Fund",
      link: "https://groww.in/mutual-funds/union-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "Axis CRISIL IBX 50:50 Gilt Plus SDL September 2027 Index Fund",
      link: "https://groww.in/mutual-funds/axis-crisil-ibx-50:50-gilt-plus-sdl-september-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/axis_groww.png",
    },
    {
      name: "BNP Paribas Overnight Fund",
      link: "https://groww.in/mutual-funds/bnp-paribas-overnight-fund-direct-growth-c",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bnp_groww.png",
    },
    {
      name: "Baroda Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "PGIM India Equity Savings Fund",
      link: "https://groww.in/mutual-funds/pgim-india-equity-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Baroda BNP Paribas Medium Duration Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-medium-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "Edelweiss Overnight Fund",
      link: "https://groww.in/mutual-funds/edelweiss-overnight-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "PGIM India Credit Risk Fund",
      link: "https://groww.in/mutual-funds/pgim-india-credit-risk-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Invesco India Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/invesco-india-bank-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "IDBI Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/idbi-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "HSBC CRISIL IBX 50:50 Gilt Plus SDL Apr 2028 Index Fund",
      link: "https://groww.in/mutual-funds/hsbc-crisil-ibx-50:50-gilt-plus-sdl-apr-2028-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Bandhan Crisil IBX Gilt April 2026 Index Fund",
      link: "https://groww.in/mutual-funds/idfc-crisil-ibx-gilt-april-2026-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "IDBI Equity Savings Fund",
      link: "https://groww.in/mutual-funds/idbi-monthly-i-come-plan-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "Invesco India Corporate Bond Fund",
      link: "https://groww.in/mutual-funds/invesco-india-active-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Sundaram Medium Duration Fund",
      link: "https://groww.in/mutual-funds/sundaram-medium-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Union Medium Duration Fund",
      link: "https://groww.in/mutual-funds/union-medium-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/union_groww.png",
    },
    {
      name: "HSBC Short Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-short-durationd-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Baroda BNP Paribas Low Duration Fund",
      link: "https://groww.in/mutual-funds/baroda-bnp-paribas-low-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/barodabnpparibasmutualfund_groww.png",
    },
    {
      name: "HSBC Money Market Fund",
      link: "https://groww.in/mutual-funds/hsbc-money-market-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "HSBC Gilt Fund",
      link: "https://groww.in/mutual-funds/hsbc-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Sundaram Money Fund",
      link: "https://groww.in/mutual-funds/sundaram-money-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Baroda Treasury Advantage Direct Fund",
      link: "https://groww.in/mutual-funds/baroda-pioneer-treasury-advantage-fund-plan-b-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
    {
      name: "Invesco India Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/invesco-india-medium-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Edelweiss CRISIL IBX 50:50 Gilt Plus SDL June 2027 Index Fund",
      link: "https://groww.in/mutual-funds/edelweiss-crisil-ibx-50:50-gilt-plus-sdl-june-2027-index-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/edelweiss_groww.png",
    },
    {
      name: "Mirae Asset Short Term Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "PGIM India Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/pgim-india-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "PGIM India Arbitrage Fund",
      link: "https://groww.in/mutual-funds/pgim-india-arbitrage-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "HSBC Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/hsbc-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Bandhan Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-super-saver-i-come-fund-medium-term-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "HSBC Short Duration(Ex) Fund",
      link: "https://groww.in/mutual-funds/hsbc-i-come-fund-s-t-p-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "BNP Paribas Short Term Fund",
      link: "https://groww.in/mutual-funds/bnp-paribas-short-term-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/bnp_groww.png",
    },
    {
      name: "Sundaram Ultra Short Term Fund",
      link: "https://groww.in/mutual-funds/sundaram-ultra-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "Invesco India Short Duration Fund",
      link: "https://groww.in/mutual-funds/invesco-india-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Invesco India Short Term Fund",
      link: "https://groww.in/mutual-funds/invesco-india-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/invesco_groww.png",
    },
    {
      name: "Taurus Dynamic Income Fund",
      link: "https://groww.in/mutual-funds/taurus-dynamic-i-come-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/taurus_groww.png",
    },
    {
      name: "Mirae Asset Savings Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-savings-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "IDBI Gilt Fund",
      link: "https://groww.in/mutual-funds/idbi-gilt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idbi_groww.png",
    },
    {
      name: "HSBC Low Duration Fund",
      link: "https://groww.in/mutual-funds/hsbc-ultra-short-term-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/hsbc_groww.png",
    },
    {
      name: "Principal Dynamic Bond Fund",
      link: "https://groww.in/mutual-funds/principal-dynamic-bond-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/sundaram_groww.png",
    },
    {
      name: "JM Short Term Plan Fund",
      link: "https://groww.in/mutual-funds/jm-short-term-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/jm_groww.png",
    },
    {
      name: "BOI AXA Ultra Short Duration Fund",
      link: "https://groww.in/mutual-funds/boi-axa-treasury-advantage-fund-direct-bonus",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/boi_groww.png",
    },
    {
      name: "Mirae Asset Savings Fund",
      link: "https://groww.in/mutual-funds/mirae-asset-savings-fund-direct-plan-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/mirae_groww.png",
    },
    {
      name: "PGIM India Short Duration Fund",
      link: "https://groww.in/mutual-funds/pgim-india-short-duration-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/dhfl_groww.png",
    },
    {
      name: "Bandhan Bond Fund",
      link: "https://groww.in/mutual-funds/idfc-super-saver-i-come-fund-investment-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/idfc_groww.png",
    },
    {
      name: "UTI Credit Risk Fund",
      link: "https://groww.in/mutual-funds/uti-credit-risk-fund-segregated-portfolio-4-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/uti_groww.png",
    },
    {
      name: "TRUSTMF Banking & PSU Debt Fund",
      link: "https://groww.in/mutual-funds/trustmf-banking-psu-debt-fund-direct-growth",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/trust_groww.png",
    },
    {
      name: "Baroda BNP Paribas Overnight Fund",
      link: "https://groww.in/mutual-funds/baroda-overnight-fund-direct-growth-invalid",
      logo: "https://assets-netstorage.groww.in/mf-assets/logos/baroda_groww.png",
    },
  ];

  const handleNextBtnClick = () => {
    setCurrentPage(currentPage + 1);

    if (currentPage + 1 > maxPageNumberLimit) {
      setMaxPageNumberLimit(maxPageNumberLimit + pageNumberLimit);
      setMinPageNumberLimit(minPageNumberLimit + pageNumberLimit);
    }
  };

  const handlePrevBtnClick = () => {
    setCurrentPage(currentPage - 1);

    if ((currentPage - 1) % pageNumberLimit === 0) {
      setMaxPageNumberLimit(maxPageNumberLimit - pageNumberLimit);
      setMinPageNumberLimit(minPageNumberLimit - pageNumberLimit);
    }
  };


  const handleAddFundToYourFund = (fund) => {
    // We will be using \n and then ": " as separator to split fund details and make it as key value pair of Name, Link and url
    const fundDetails = `Name: ${fund.name}\nLink: ${fund.link}\nURL: ${fund.logo}`;

      axios
      .post("/AddFundToYourFund", { userId, fundDetails })
      .then((response) => {
        toast.success("Added successfully!");
      })
      .catch((error) => {
        if (error.response.status == 400) {
          toast.error("This Fund is already in Your Fund")
          console.error("This Fund is already in Your Fund DataBase:", error);
        } else {
          toast.error("Failed to save Fund in Your Fund data");
        }
      });
  };


  return (
    <div>
      <div className="searchBar">
        <input
          type="text"
          placeholder="Search Mutual Funds"
          value={searchQuery}
          onChange={handleSearchInputChange}
        />
      </div>

      <div className="userNameDiv">
        {userName ? (
          <h2 className="userKaName">Hi {userName}!</h2>
        ) : (
          <p className="NoActiveUser">No active user!</p>
        )}
      </div>

      <div className="mutualFund">
        {currentItems.map((fund, index) => (
          <div key={index}>
            <a href={fund.link} target="_blank">
              <img src={fund.logo} alt="" />
              {fund.name}
            </a>
            <button
              className="handleAddFundToYourFundBt"
              onClick={() => handleAddFundToYourFund(fund)}
            >
              Add To Your Funds
            </button>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="pagination">
        <button
          className="prev"
          onClick={handlePrevBtnClick}
          disabled={currentPage === 1}
        >
          Prev
        </button>
        {Array.from({ length: totalPages }, (_, index) => {
          if (index < maxPageNumberLimit && index >= minPageNumberLimit) {
            return (
              <button
                key={index}
                onClick={() => paginate(index + 1)}
                className={currentPage === index + 1 ? "active" : ""}
              >
                {index + 1}
              </button>
            );
          } else {
            return null;
          }
        })}
        <button
          className="next"
          onClick={handleNextBtnClick}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
}
