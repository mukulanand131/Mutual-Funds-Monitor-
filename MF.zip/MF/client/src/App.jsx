import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import axios from "axios";
import { Toaster } from "react-hot-toast";
import { UserContextProvider } from "../context/userContext";
import Dashboard from "./pages/Dashboard";
import { Logout } from "./pages/Logout";
import AllFunds from "./pages/allFunds";
import ContactUs from "./pages/contact";
import YourFundsComponent from "./pages/yourFunds";

axios.defaults.baseURL = "http://localhost:8000";
axios.defaults.withCredentials = true;

function App() {
  return (
    <UserContextProvider>
      <Navbar />
      <Toaster position="bottom-right" toastOptions={{ duration: 3000 }} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/logout" element={<Logout />} />
        <Route path="/allFunds" element={<AllFunds />} />
        <Route path="/yourFunds" element={<YourFundsComponent />} />
        <Route path="/contact" element={<ContactUs />} />

      </Routes>
    </UserContextProvider>
  );
}

export default App;
