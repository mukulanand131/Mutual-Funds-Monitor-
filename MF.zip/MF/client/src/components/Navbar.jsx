import "../../public/Navbar.css";
import React, { useContext, useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios"; // Import axios for making HTTP requests
import { UserContext } from "../../context/userContext"; // Import the UserContext
import { toast } from 'react-hot-toast';

const Navbar = () => {
  const location = useLocation();
  const { isAuthenticated, setIsAuthenticated } = useContext(UserContext); // Access the isAuthenticated state and setIsAuthenticated function from UserContext

  // State for userName
  const [userName, setUserName] = useState(null);

  const handleLogout = async () => {
    try {
      // Send a GET request to the logout endpoint
      await axios.get("/logout");

      // Clear JWT token from client-side storage (cookie)
      document.cookie =
        "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

      toast.success('Login Successful. Welcome!');

      // Redirect user to login page or any other appropriate page
      window.location.href = "/login";
      // Update authentication context to reflect logout
      // setIsAuthenticated(false);

      // Display logout success message
      // window.alert("Logged out successfully.");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  // Define navigation links based on the current location and authentication status
  const navLinksHome = [
    { path: "/", name: "Home" },
    { path: "/register", name: "Register" },
    { path: "/login", name: "Login" },
  ];

  const navLinksDashboard = [
    { path: "/dashboard", name: "Dashboard" },
    { path: "/yourFunds", name: "Your Funds" },
    { path: "/allFunds", name: "All Funds" },
    { path: "/contact", name: "Contact Us" },
    // Include the Logout link here
    { path: "/logout", name: "Logout", onClick: handleLogout },
  ];

  // Determine which set of navigation links to display based on the current location and authentication status
  let navLinks;
  if (
    location.pathname === "/dashboard" ||
    location.pathname === "/yourFunds" ||
    location.pathname === "/allFunds" ||
    location.pathname === "/contact"
  ) {
    navLinks = navLinksDashboard;
  } else {
    navLinks = navLinksHome;
  }

  return (
    <nav className="navbar">
      <div className="navbar-left">Mutual Funds Monitor</div>
      <div className="navbar-right">
        {/* Display userName if available */}
        {/* <div>{userName ? `Hi, ${userName}!` : null}</div> */}
        {navLinks.map((link, index) => (
          <React.Fragment key={index}>
            {/* Check if onClick handler is provided, if yes, use onClick, otherwise use Link */}
            {link.onClick ? (
              <a
                onClick={link.onClick}
                className={link.path === location.pathname ? "active" : ""}
              >
                {link.name}
              </a>
            ) : (
              <Link
                to={link.path}
                className={link.path === location.pathname ? "active" : ""}
              >
                {link.name}
              </Link>
            )}
          </React.Fragment>
        ))}
      </div>
    </nav>
  );
};

export default Navbar;


