const express = require('express');
const router = express.Router();
const cors = require('cors');
// const { test, registerUser, loginUser, getProfile, logoutUser, AddFundToYourFund, getFundData, removeFundFromYourFunds } = require('../controllers/authControllers');
const { test, registerUser, loginUser, getProfile, logoutUser, AddFundToYourFund, getFundData, removeFundFromYourFunds, getPythonScriptOutputForHoldingCompanyList } = require('../controllers/authControllers');


// middleware
router.use(
    cors({
        credentials: true,
        origin: 'http://localhost:5173'
    })
);

// Routes
router.get('/', test);
router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/profile', getProfile);
router.get('/logout', logoutUser);

// Add the route for saving fund data for a particular user
router.post('/AddFundToYourFund', AddFundToYourFund);

// Add a new route to fetch user's fund data
router.get('/fundData', getFundData);

// Route for removing funds
router.delete('/removeFund/:userId/:fundId', removeFundFromYourFunds);

router.post('/pythonData', getPythonScriptOutputForHoldingCompanyList); // New route for Python script output
// In your authRoutes.js or wherever you handle the route
const { runPythonScript } = require('../controllers/authControllers');

router.post('/executePythonScript', async (req, res) => {
    try {
        const { fundURL } = req.body;
        console.log('Received fundURL:', fundURL); // Add this line to verify the received fundURL
        const pythonOutput = await runPythonScript(fundURL);
        res.status(200).json({ data: pythonOutput });
    } catch (error) {
        console.error('Error executing Python script:', error);
        res.status(500).json({ error: 'Failed to execute Python script' });
    }
});


module.exports = router;


