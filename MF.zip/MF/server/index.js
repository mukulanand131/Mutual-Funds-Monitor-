// const express = require('express');
// const dotenv = require('dotenv').config();
// const cors = require('cors');
// const { mongoose } = require('mongoose');
// const cookieParser = require('cookie-parser');


// const app = express();


// // Database connection
// mongoose.connect(process.env.MONGO_URL)
// .then(() => console.log('Database connected'))
// .catch((err) => console.log('Database not connected', err))


// // Middleware
// app.use(express.json());
// app.use(cookieParser());
// app.use(express.urlencoded({extended: false}))


// app.use('/', require('./routes/authRoutes'))


// const port = 8000;
// app.listen(port, () => console.log(`Server is running on port ${port}`));


// const express = require('express');
// const dotenv = require('dotenv').config();
// const cors = require('cors');
// const { mongoose } = require('mongoose');
// const cookieParser = require('cookie-parser');

// const app = express();

// // Database connection
// mongoose.connect(process.env.MONGO_URL)
// .then(() => console.log('Database connected'))
// .catch((err) => console.log('Database not connected', err));

// // // Middleware
// // app.use(express.json());
// // app.use(cookieParser());
// // app.use(express.urlencoded({extended: false}));
// // app.use(cors());

// // // Routes
// // app.use('/', require('./routes/authRoutes'));
// // app.use('/funds', require('./routes/fundRoutes')); // Include fund routes

// // const port = process.env.PORT || 8000;
// // app.listen(port, () => console.log(`Server is running on port ${port}`));


// // Middleware
// app.use(express.json());
// app.use(cookieParser());
// app.use(express.urlencoded({ extended: false }));

// // CORS configuration
// const corsOptions = {
//   origin: 'http://localhost:5173',
//   credentials: true, // Allow credentials
// };

// app.use(cors(corsOptions));

// // Routes
// app.use('/', require('./routes/authRoutes'));
// app.use('/funds', require('./routes/fundRoutes')); // Include fund routes

// const port = process.env.PORT || 8000;
// app.listen(port, () => console.log(`Server is running on port ${port}`));

const express = require('express');
const dotenv = require('dotenv').config();
const cors = require('cors');
const mongoose = require('mongoose'); // Corrected import
const cookieParser = require('cookie-parser');
// const morgan = require('morgan');


const app = express();

// Use Morgan middleware for HTTP request logging
// app.use(morgan('combined')); // Logs in the Apache combined format

// Database connection
mongoose.connect(process.env.MONGO_URL)
  .then(() => console.log('Database connected'))
  .catch((err) => console.log('Database not connected', err));

// Middleware
const corsOptions = {
  origin: 'http://localhost:5173',
  credentials: true, // Allow credentials
};

app.use(cors(corsOptions)); // CORS middleware

app.use(express.json());
app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));

// Routes
app.use('/', require('./routes/authRoutes'));
// app.use('/funds', require('./routes/fundRoutes')); // Include fund routes

const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`Server is running on port ${port}`));
