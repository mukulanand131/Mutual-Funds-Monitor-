const User = require('../models/user');
const { hashPassword, comparePassword } = require('../helpers/auth')
const jwt = require('jsonwebtoken');
const UserModel = require('../models/user')
const { spawn } = require('child_process');



const test = (req, res) => {
    res.json('test is working')
}


// Register End point
const registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        // Check if name was entered
        if (!name) {
            return res.json({
                error: 'Name is required!'
            })
        };
        //Check is password is good 
        if (!password || password.length < 6) {
            return res.json({
                error: 'Password is required and it should be at least 6 characters long'
            })
        };
        // Check email
        const exist = await User.findOne({ email });
        if (exist) {
            return res.json({
                error: 'This email already exists.Try with different one!'
            })

        }

        // Hashing Password
        const hashedPassword = await hashPassword(password)
        // Creating user in mongoDB
        const user = await User.create({
            name,
            email,
            password: hashedPassword
        })

        return res.json(user)

    } catch (error) {
        console.log(error)
    }
};


// Login End point
const loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.json({
                error: 'No user found associated with the provided email ID!'
            });
        }

        // Check if password matches
        const match = await comparePassword(password, user.password);
        if (match) {
            // Generate JWT token
            jwt.sign({ email: user.email, id: user._id, name: user.name }, process.env.JWT_SECRET, {}, (err, token) => {
                if (err) {
                    console.log(err);
                    return res.status(500).json({ error: 'Failed to generate token' });
                }
                // Set user data in the response
                const userData = { name: user.name, email: user.email }; // Customize as needed
                res.cookie('token', token).json({ user: userData }); // Return user data
            });
        } else {
            return res.json({
                error: 'Passwords do not match!'
            });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: 'Internal server error' });
    }
};


const getProfile = (req, res) => {
    // console.log(req)
    const { token } = req.cookies
    if (token) {
        jwt.verify(token, process.env.JWT_SECRET, {}, async (err, user) => {
            if (err) throw err;
            res.json(user)
        })
    } else {
        res.json(null)
    }
}

// Logout Endpoint
const logoutUser = (req, res) => {
    res.clearCookie('token').json({ message: 'Logged out successfully' });
};


//AddFundToYourFund end point
const AddFundToYourFund = async (req, res) => {
    console.log(req.body);

    try {
        const { userId, fundDetails } = req.body;
        console.log(userId)
        console.log(fundDetails)

        // Check if userId and fundDetails are present in the request body
        if (!userId || !fundDetails) {
            return res.status(400).json({ error: 'Missing required data' });
        }

        // Find the user by userId
        const user = await UserModel.findById(userId);
        console.log(user)
        // console.log(userId)


        // If user is not found, return an error
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }


        // Check if the fundDetails value already exists in the user's fundDetails array
        const isDuplicate = user.fundData.some(item => item.data === fundDetails);

        if (isDuplicate) {
            return res.status(400).json({ error: 'Duplicate entry in Fund array' });
        }

        // Add the copied data to the array with the associated user ID
        user.fundData.push({ userId, data: fundDetails });

        // Save the updated user document
        await user.save();

        // Send success response
        res.status(200).json({ message: 'Fund Details saved successfully' });
    } catch (error) {
        console.error('Error saving pasted data:', error);
        res.status(500).json({ error: 'Failed to save Fund Details' });
    }
};


// getFundData End point
const getFundData = async (req, res) => {
    try {
    const myData = await UserModel.find({})
      res.json(myData);

    } catch (error) {
      console.error('Error fetching user fund data:', error);
      res.status(500).json({ error: 'Failed to fetch user fund data' });
    }
  };


// End point to remove a fund from the user's fundData
const removeFundFromYourFunds = async (req, res) => {
    try {
      const { fundId, userId } = req.params;
    //   console.log(fundId);
    //   console.log(userId);
  
      // Find the user by ID and update the fundData array to remove the specified fund
      const user = await UserModel.findByIdAndUpdate(
        userId,
        { $pull: { fundData: { _id: fundId } } }, // Remove the fund with the given ID from the array
        { new: true } // Return the updated user document
      );
  
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      res.json({ message: 'Fund removed successfully', user });
    } catch (error) {
      console.error('Error removing fund:', error);
      res.status(500).json({ error: 'Failed to remove fund' });
    }
  };


// // Function to run Python script with fund.Link parameter
// const runPythonScript = (fundLink) => {
//     return new Promise((resolve, reject) => {
//         const pythonProcess = spawn('C:\\Python 310\\python.exe', [
//             'C:\\Users\\mukul\\OneDrive\\Documents\\one drive backup\\Desktop\\New folder\\server\\python_scripts\\ofAnyMF.py',
//             fundLink // Pass the fund.Link as a parameter to the Python script
//         ]);
//         console.log(fundLink); // Ensure fundLink is correct here

//         let data = '';

//         pythonProcess.stdout.on('data', (chunk) => {
//             data += chunk.toString();
//         });

//         pythonProcess.stderr.on('data', (data) => {
//             console.error(`Python script error: ${data}`);
//         });

//         pythonProcess.on('close', (code) => {
//             if (code === 0) {
//                 resolve(data);
//             } else {
//                 reject(`Python script exited with code ${code}`);
//             }
//         });
//     });
// };



// // New endpoint to run Python script and return data
// const getPythonScriptOutputForHoldingCompanyList = async (req, res) => {
//     try {
//         console.log(req.body);
//         // Retrieve the fund URL from the request body
//         const { fundURL } = req.body;
//         console.log('getPythonScriptOutputForHoldingCompanyList', fundURL);
        
//         // Run Python script with the fund URL as parameter
//         const pythonOutput = await runPythonScript(fundURL);
        
//         // Send the Python script output as response
//         res.status(200).json({ data: pythonOutput });
//     } catch (error) {
//         console.error('Error running Python script:', error);
//         res.status(500).json({ error: 'Failed to run Python script' });
//     }
// };


const runPythonScript = (pythonPath, fundLink) => {
    return new Promise((resolve, reject) => {
        const pythonProcess = spawn('C:\\Python 310\\python.exe', [
            pythonPath,
            fundLink // Pass the fund.Link as a parameter to the Python script
        ]);
        console.log(`Running ${pythonPath} with fund link: ${fundLink}`);

        let data = '';

        pythonProcess.stdout.on('data', (chunk) => {
            data += chunk.toString();
            // Send each chunk of data back to the client
            // res.write(data);
            // console.log(data);
        });

        pythonProcess.stderr.on('data', (data) => {
            console.error(`Python script error: ${data}`);
        });

        pythonProcess.on('close', (code) => {
            if (code === 0) {
                resolve(data);
            } else {
                reject(`Python script ${pythonPath} exited with code ${code}`);
            }
        });
    });
};

// New endpoint to run Python scripts and return data
const getPythonScriptOutputForHoldingCompanyList = async (req, res) => {
    try {
        console.log(req.body);
        // Retrieve the fund URL from the request body
        const { fundURL } = req.body;
        console.log('getPythonScriptOutputForHoldingCompanyList', fundURL);
        
        // Run Python scripts with the fund URL as parameter
        const pythonOutput1 = await runPythonScript('python_scripts/ofAnyMF.py', fundURL);
        const pythonOutput2 = await runPythonScript('python_scripts/ofAnyMF1.py', fundURL);
        const pythonOutput3 = await runPythonScript('python_scripts/ofAnyMF2.py', fundURL);
        
        // Send the Python script outputs as response
        res.status(200).json({ 
            data1: pythonOutput1,
            data2: pythonOutput2,
            data3: pythonOutput3
        });
    } catch (error) {
        console.error('Error running Python scripts:', error);
        res.status(500).json({ error: 'Failed to run Python scripts' });
    }
};






module.exports = {
    test,
    registerUser,
    loginUser,
    getProfile,
    logoutUser,
    AddFundToYourFund,
    getFundData,
    removeFundFromYourFunds,
    getPythonScriptOutputForHoldingCompanyList,
    runPythonScript
}
