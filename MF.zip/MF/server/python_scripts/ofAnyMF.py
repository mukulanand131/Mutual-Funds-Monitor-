# print("Hi Mahadev Ji, Pranam")

# import sys
# import companies_ticker_and_Exchange

# companies_ticker_and_Exchange = companies_ticker_and_Exchange.companies_ticker_and_Exchange
# print(companies_ticker_and_Exchange["ABBINDIALTD"])

# # print("Number of arguments:", len(sys.argv))
# # print("Argument List:", str(sys.argv))

# # URL of particular MF
# url = sys.argv[1]

# fund_name = (url[30:].replace("-", " ")).title()
# print(fund_name)


# import requests
# from bs4 import BeautifulSoup
# import time

# # Getting content of url
# response = requests.get(url)

# # Parsing the content of url
# soup = BeautifulSoup(response.text, 'html.parser')
# # Printing parsed data
# # print(soup)

# # To get the value of last day closed
# # class_for_last_day_closed = "scroll11 scroll11FadeOut"
# class_for_last_day_closed = "fd12Cell contentPrimary bodyLargeHeavy"
# Last_day_closed = soup.find(class_=class_for_last_day_closed).text.strip()[1:]
# Last_day_closed = Last_day_closed.replace(",","")
# Last_day_closed = float(Last_day_closed)
# print(Last_day_closed)

# # Finding the script_content for further working on it to get the list of holdings companies
# script_content = soup.find('script', {'id': "__NEXT_DATA__"}).text
# # print(script_content)

# # To get the index from where holdings is starting and ending to get the list of holdings companies
# holdings_start = script_content.find('"holdings":')
# holdings_end = script_content.find('"nav":')
# # print(holdings_start, holdings_end)
# holdings_text = script_content[holdings_start+11:holdings_end-1]
# # print(holdings_text)

# # To convert holding_text into list of dictionary of holding companies
# # Replace 'null' with None
# holdings_text = holdings_text.replace('null', 'None')
# # Convert text to list of dictionaries
# holdings_list = eval(holdings_text)

# # Print the list of dictionaries
# # print(holdings_list)

# # Print the list of dictionaries
# # print(holdings_list)
# # type(holdings_list)

# # To get the 'stock_search_id' of all the holding companies
# # Extract 'stock_search_id' from each dictionary
# stock_search_company_name = [(((d['company_name']).upper()).replace("AND", "&")).replace("LTD.","LTD") for d in holdings_list]
# stock_correcponding_holding = [d['corpus_per'] for d in holdings_list]


# # Print the list of 'stock_search_id' values
# # print(stock_search_company_name)
# # print(stock_correcponding_holding)

# # print(len(stock_correcponding_holding))
# # print(len(stock_search_company_name))

# for i in stock_search_company_name:
#   if ("FUND" or "DIRECT" or "GROWTH") in i:
#     stock_search_company_name.remove(i)

# # print(len(stock_search_company_name_stock_correcponding_holding_pairs))

# stock_search_company_name_char_str = []
# for i in stock_search_company_name:
#   stock_search_company_name_char_str.append(''.join(char for char in i if char.isalpha()))

# stock_search_company_name_stock_correcponding_holding_pairs = {k: v for k, v in zip(stock_search_company_name_char_str, stock_correcponding_holding)}
# # print(stock_search_company_name_char_str)
# # print(stock_search_company_name_stock_correcponding_holding_pairs)

# stock_search_company_name_char_str = []
# for i in stock_search_company_name:
#   stock_search_company_name_char_str.append(''.join(char for char in i if char.isalpha()))


# for i in range(2):
#   # To remove none NSE symbol company from list
#   for k,v in companies_ticker_and_Exchange.items():
#     if v[0] == "None":
#       item_to_remove = k
#       stock_search_company_name = [company for company in stock_search_company_name if company != item_to_remove]
#       # print(item_to_remove)

#   print(len(stock_search_company_name))

# def last_day_price_according_to_percentage_holding(ticker_and_Exchange,percentage_holding):
#   try:
#     exchange = "NSE"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[0]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_last_day_closed = "P6K39c"

#     # Getting Last Day price and removing rupee sign
#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text.strip()[1:]

#     # removing , sign
#     Last_day_closed = Last_day_closed.replace(",","")

#     # Converting into float
#     Last_day_closed = float(Last_day_closed)

#     # printing price
#     # print(Last_day_closed)
#     # print(type(Last_day_closed))
#     return (Last_day_closed * percentage_holding)/100
#   except:
#     exchange = "BOM"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[1]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_last_day_closed = "P6K39c"

#     # Getting Last Day price and removing rupee sign
#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text.strip()[1:]

#     # removing , sign
#     Last_day_closed = Last_day_closed.replace(",","")

#     # Converting into float
#     Last_day_closed = float(Last_day_closed)

#     # printing price
#     # print(Last_day_closed)
#     # print(type(Last_day_closed))
#     return (Last_day_closed * percentage_holding)/100

# # To store companies_ticker_and_Exchange_of_this_particular_MF
# companies_ticker_and_Exchange_of_this_particular_MF = dict()

# Cummulative_last_day_price_according_to_percentage_holding_of_this_MF = 0
# for stock_search_company_name_of_one in (stock_search_company_name_char_str):
#   companies_ticker_and_Exchange_of_this_particular_MF[stock_search_company_name_of_one] = companies_ticker_and_Exchange[stock_search_company_name_of_one]
# #   print(companies_ticker_and_Exchange_of_this_particular_MF)
#   # To fetch the last day price of stock_search_company_name_of_one of this MF
#   Cummulative_last_day_price_according_to_percentage_holding_of_this_MF = Cummulative_last_day_price_according_to_percentage_holding_of_this_MF + last_day_price_according_to_percentage_holding(companies_ticker_and_Exchange_of_this_particular_MF[stock_search_company_name_of_one], stock_search_company_name_stock_correcponding_holding_pairs[stock_search_company_name_of_one])

# # len(companies_ticker_and_Exchange_of_this_particular_MF)
# # companies_ticker_and_Exchange_of_this_particular_MF
# print(Cummulative_last_day_price_according_to_percentage_holding_of_this_MF)


# # For illustration of all the stocks of this MF is getting fetched properly
# def last_day_and_current_price(ticker_and_Exchange):
#   try:
#     exchange = "NSE"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[0]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_last_day_closed = "P6K39c"
#     class_for_present = "YMlKec fxKbKc"

#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text
#     present_price = soup.find(class_=class_for_present).text

#     # removing rupee sign
#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text.strip()[1:]
#     present_price = soup.find(class_=class_for_present).text.strip()[1:]


#     # removing , sign
#     Last_day_closed = Last_day_closed.replace(",","")
#     present_price = present_price.replace(",","")

#     # Converting into float
#     Last_day_closed = float(Last_day_closed)
#     present_price = float(present_price)

#     # printing price
#     # print(Last_day_closed)
#     # print(type(Last_day_closed))
#     return Last_day_closed, present_price
#   except:
#     exchange = "BOM"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[1]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_last_day_closed = "P6K39c"
#     class_for_present = "YMlKec fxKbKc"

#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text
#     present_price = soup.find(class_=class_for_present).text

#     # removing rupee sign
#     Last_day_closed = soup.find(class_=class_for_last_day_closed).text.strip()[1:]
#     present_price = soup.find(class_=class_for_present).text.strip()[1:]


#     # removing , sign
#     Last_day_closed = Last_day_closed.replace(",","")
#     present_price = present_price.replace(",","")

#     # Converting into float
#     Last_day_closed = float(Last_day_closed)
#     present_price = float(present_price)

#     # printing price
#     # print(Last_day_closed)
#     # print(type(Last_day_closed))
#     return Last_day_closed, present_price

# # To check that all the companies of any MF is in companies ticker or not
# for stock_search_company_name_of_one_with_space, stock_search_company_name_of_one_with_out_space in zip(stock_search_company_name, stock_search_company_name_char_str):
#     last_day, current_price = last_day_and_current_price(companies_ticker_and_Exchange_of_this_particular_MF[stock_search_company_name_of_one_with_out_space])
#     current_net = f"{(current_price - last_day):.2f}"
#     current_net_percent = f"{(float(current_net)/last_day)*100:.2f} %"

#     print(stock_search_company_name_of_one_with_space, ":", last_day, current_price, current_net, current_net_percent)

# # To get current_price_according_to_holding_percentage
# def current_price_according_to_holding_percentage(ticker_and_Exchange,percentage_holding):
#   try:
#     exchange = "NSE"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[0]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_present = "YMlKec fxKbKc"

#     # present_price = soup.find(class_=class_for_present).text

#     # removing rupee sign
#     present_price = soup.find(class_=class_for_present).text.strip()[1:]

#     # removing , sign
#     present_price = present_price.replace(",","")

#     # Converting into float
#     present_price = float(present_price)

#     # To get price according to holdings
#     return (present_price * percentage_holding)/100
#   except:
#     exchange = "BOM"
#     url = f'https://www.google.com/finance/quote/{ticker_and_Exchange[1]}:{exchange}?hl=en'

#     response = requests.get(url)

#     soup = BeautifulSoup(response.text, 'html.parser')
#     class_for_present = "YMlKec fxKbKc"

#     # present_price = soup.find(class_=class_for_present).text

#     # removing rupee sign
#     present_price = soup.find(class_=class_for_present).text.strip()[1:]

#     # removing , sign
#     present_price = present_price.replace(",","")

#     # Converting into float
#     present_price = float(present_price)

#     # To get price according to holdings
#     return (present_price * percentage_holding)/100

# # For calculating current percentage change
# def current_MF_status(stock_search_company_name, Cummulative_last_day_price_according_to_percentage_holding_of_this_MF):
#   Cummulative_current_price_according_to_percentage_holding_of_this_MF = 0
#   for stock_search_company_name_of_one in stock_search_company_name_char_str:
#     # To get the current price of the one stock of this Mf according to their holding
#     Cummulative_current_price_according_to_percentage_holding_of_this_MF = Cummulative_current_price_according_to_percentage_holding_of_this_MF + current_price_according_to_holding_percentage(companies_ticker_and_Exchange_of_this_particular_MF[stock_search_company_name_of_one], stock_search_company_name_stock_correcponding_holding_pairs[stock_search_company_name_of_one])

#   return ((Cummulative_current_price_according_to_percentage_holding_of_this_MF - Cummulative_last_day_price_according_to_percentage_holding_of_this_MF)/Cummulative_current_price_according_to_percentage_holding_of_this_MF)*100

# # To get value of MF at regular interval of time
# # interval = 30
# print()
# print(fund_name)
# # for i in range(1):
# #   current_MF_status_according_to_percentage_holdings = current_MF_status(stock_search_company_name, Cummulative_last_day_price_according_to_percentage_holding_of_this_MF)
# #   current_nav = float(Last_day_closed) + ((float(Last_day_closed)*current_MF_status_according_to_percentage_holdings)/100)
# #   # print(current_MF_status(stock_search_company_name))
# #   # print(current_nav)
# #   print(f"Last day NAV: {float(Last_day_closed):.2f}, Percentage increase: {current_MF_status_according_to_percentage_holdings:.2f} % & Current NAV: {current_nav:.2f}")

#   # time.sleep(interval)